
<head>
<style type="text/css">


/* Estilos del contenedor */
.sidebar {


  width: auto;
  height: 900px;
}

/* Tamaño del scroll */
.sidebar::-webkit-scrollbar {
  width: 8px;
}

 /* Estilos barra (thumb) de scroll */
.sidebar::-webkit-scrollbar-thumb {
  background: #ccc;
  border-radius: 4px;
}

.sidebar::-webkit-scrollbar-thumb:active {
  background-color: #999999;
}

.sidebar::-webkit-scrollbar-thumb:hover {
  background: #b3b3b3;
  box-shadow: 0 0 2px 1px rgba(0, 0, 0, 0.2);
}

 /* Estilos track de scroll */
.sidebar::-webkit-scrollbar-track {
  background: #e1e1e1;
  border-radius: 4px;
}

.sidebar::-webkit-scrollbar-track:hover, 
.sidebar::-webkit-scrollbar-track:active {
  background: #d4d4d4;
}
</style>
</head>
<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="{{('/')}}admin" class="brand-link">
<img src="/img/LOGO.png" alt="alumax_logo" class="image elevation-4" style="max-height: 77px;"
           style="opacity: .8">
        <span class="brand-text font-weight-light"></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                @can('client_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.clients.index") }}" class="nav-link {{ request()->is('admin/clients') || request()->is('admin/clients/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-user-plus">

                            </i>
                            <p>
                                <span>{{ trans('cruds.client.title') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('project_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.projects.index") }}" class="nav-link {{ request()->is('admin/projects') || request()->is('admin/projects/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-briefcase">

                            </i>
                            <p>
                                <span>{{ trans('cruds.project.title') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('note_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.notes.index") }}" class="nav-link {{ request()->is('admin/notes') || request()->is('admin/notes/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-sticky-note">

                            </i>
                            <p>
                                <span>{{ trans('cruds.note.title') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('document_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.documents.index") }}" class="nav-link {{ request()->is('admin/documents') || request()->is('admin/documents/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-file-alt">

                            </i>
                            <p>
                                <span>{{ trans('cruds.document.title') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                
                @can('product_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.products.index") }}" class="nav-link {{ request()->is('admin/products') || request()->is('admin/products/*') ? 'active' : '' }}">
                            <i class="fa-fw far fa-window-restore">

                            </i>
                            <p>
                                <span>{{ trans('cruds.product.title') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('cost_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.costs.index") }}" class="nav-link {{ request()->is('admin/costs') || request()->is('admin/costs/*') || request()->is('admin/accesories/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-window-restore">
                            </i>
                            <p>
                                <span>{{ trans('cruds.cost.title') }}/{{ trans('cruds.cost.title_list') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('transaction_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.transactions.index") }}" class="nav-link {{ request()->is('admin/transactions') || request()->is('admin/transactions/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-credit-card">

                            </i>
                            <p>
                                <span>{{ trans('cruds.transaction.title') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('quotes_access')  
                    <li class="nav-item">
                        <a href="{{ route("admin.quotes.index") }}" class="nav-link {{ request()->is('admin/quotes') || request()->is('admin/quotes/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-file-invoice-dollar">

                            </i>
                            <p>
                                <span>{{strtoupper(trans('cruds.quotes.title'))}}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('bills_access')  
                    <li class="nav-item">
                        <a href="{{ route("admin.bills.index") }}" class="nav-link {{ request()->is('admin/bills') || request()->is('admin/bills/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-file-invoice">

                            </i>
                            <p>
                                <span>{{strtoupper(trans('cruds.bills.title'))}}</span>
                            </p>
                        </a>
                    </li>
                @endcan
               @can('receipts_access')  
                    <li class="nav-item">
                        <a href="{{ route("admin.receipts.index") }}" class="nav-link {{ request()->is('admin/receipts') || request()->is('admin/receipts/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-receipt">

                            </i>
                            <p>
                                <span>{{strtoupper(trans('cruds.receipts.title'))}}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                 @can('client_report_access')
                    <li class="nav-item">
                        <a href="{{ route("admin.client-reports.index") }}" class="nav-link {{ request()->is('admin/client-reports') || request()->is('admin/client-reports/*') ? 'active' : '' }}">
                            <i class="fa-fw fas fa-chart-line">

                            </i>
                            <p>
                                <span>{{ trans('cruds.clientReport.title') }}</span>
                            </p>
                        </a>
                    </li>
                @endcan
                @can('client_management_setting_access')
                    <li class="nav-item has-treeview {{ request()->is('admin/currencies*') ? 'menu-open' : '' }} {{ request()->is('admin/transaction-types*') ? 'menu-open' : '' }} {{ request()->is('admin/income-sources*') ? 'menu-open' : '' }} {{ request()->is('admin/client-statuses*') ? 'menu-open' : '' }} {{ request()->is('admin/project-statuses*') ? 'menu-open' : '' }}">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fas fa-cogs">

                            </i>
                            <p>
                                <span>{{ trans('cruds.clientManagementSetting.title') }}</span>
                                <i class="right fa fa-fw fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @can('currency_access')
                                <li class="nav-item">
                                    <a href="{{ route("admin.currencies.index") }}" class="nav-link {{ request()->is('admin/currencies') || request()->is('admin/currencies/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-money-bill">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.currency.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('transaction_type_access')
                                <li class="nav-item">
                                    <a href="{{ route("admin.transaction-types.index") }}" class="nav-link {{ request()->is('admin/transaction-types') || request()->is('admin/transaction-types/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-money-check">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.transactionType.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('income_source_access')
                                <li class="nav-item">
                                    <a href="{{ route("admin.income-sources.index") }}" class="nav-link {{ request()->is('admin/income-sources') || request()->is('admin/income-sources/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-database">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.incomeSource.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('client_status_access')
                                <li class="nav-item">
                                    <a href="{{ route("admin.client-statuses.index") }}" class="nav-link {{ request()->is('admin/client-statuses') || request()->is('admin/client-statuses/*') ? 'active' : '' }}">
                                     <i class="fas fa-user-check">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.clientStatus.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('project_status_access')
                                <li class="nav-item">
                                    <a href="{{ route('admin.project-statuses.index') }}" class="nav-link {{ request()->is('admin/project-statuses') || request()->is('admin/project-statuses/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-briefcase">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.projectStatus.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                                <li class="nav-item">
                                    <a href="{{ route('admin.caracteristica_quotes.index') }}" class="nav-link {{ request()->is('admin/caracteristica_quotes') || request()->is('admin/aracteristica_quotes/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-file-contract">

                                        </i>
                                        <p>
                                            <span>Características Cotización</span>
                                        </p>
                                    </a>
                                </li>
                        </ul>
                    </li>
                @endcan
                @can('user_management_access')
                    <li class="nav-item has-treeview {{ request()->is('admin/permissions*') ? 'menu-open' : '' }} {{ request()->is('admin/roles*') ? 'menu-open' : '' }} {{ request()->is('admin/users*') ? 'menu-open' : '' }}">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw fas fa-users">

                            </i>
                            <p>
                                <span>{{ trans('cruds.userManagement.title') }}</span>
                                <i class="right fa fa-fw fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @can('permission_access')
                                <li class="nav-item">
                                    <a href="{{ route("admin.permissions.index") }}" class="nav-link {{ request()->is('admin/permissions') || request()->is('admin/permissions/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.permission.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('role_access')
                                <li class="nav-item">
                                    <a href="{{ route("admin.roles.index") }}" class="nav-link {{ request()->is('admin/roles') || request()->is('admin/roles/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-briefcase">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.role.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('user_access')
                                <li class="nav-item">
                                    <a href="{{ route("admin.users.index") }}" class="nav-link {{ request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-user">

                                        </i>
                                        <p>
                                            <span>{{ trans('cruds.user.title') }}</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endcan
                 @can('sobrante_access')
                    <li class="nav-item has-treeview {{ request()->is('admin/permissions*') ? 'menu-open' : '' }} {{ request()->is('admin/roles*') ? 'menu-open' : '' }} {{ request()->is('admin/users*') ? 'menu-open' : '' }}">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw fas fa-server">

                            </i>
                            <p>
                                <span>Otros</span>
                                <i class="right fa fa-fw fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            @can('backups_access')
                                <li class="nav-item">
                                    <a href="/backup" class="nav-link {{ request()->is('backup') || request()->is('backup/*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-database">

                                        </i>
                                        <p>
                                            <span>Respaldo/Restauración</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('binnacle_access')
                                <li class="nav-item">
                                    <a href="/bitacora" class="nav-link {{ request()->is('bitacora') || request()->is('bitacora*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-file-contract">

                                        </i>
                                        <p>
                                            <span>Bitácora</span>
                                        </p>
                                    </a>
                                </li>
                            @endcan
                            @can('sobrante_access')
                            <li class="nav-item">
                                    <a href="{{route('admin.sobrantes.index')}}" class="nav-link {{ request()->is('admin/sobrantes') || request()->is('admin/sobrantes*') ? 'active' : '' }}">
                                        <i class="fa-fw fas fa-window-restore"">

                                        </i>
                                        <p>
                                            <span>Sobrantes</span>
                                        </p>
                                    </a>
                            </li>
                       
                            @endcan
                        </ul>
                    </li>
                @endcan
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                        <p>
                            <i class="fas fa-fw fa-sign-out-alt">

                            </i>
                            <span>{{ trans('global.logout') }}</span>
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>