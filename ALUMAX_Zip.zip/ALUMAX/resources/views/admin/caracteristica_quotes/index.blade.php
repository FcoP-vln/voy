@extends('layouts.admin')
@section('content')

<h1>{{trans('cruds.quotes_descriptions.title')}}</h1>


    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="#new" data-toggle="modal">
            	
                {{ trans('global.add') }} 
            </a>
        </div>
    </div>

<div class="card">
    <div class="card-header">
        {{trans('cruds.quotes_descriptions.title_singular')}} - {{ trans('global.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable">
                <thead>
                    <tr>
                        <th width="10">
                            {{ trans('cruds.note.fields.id') }}
                        </th>
                        <th>
                           {{trans('cruds.quotes_descriptions.fields.type')}}
                        </th>
                        <th>
                           {{trans('global.description')}}
                        </th>
                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach( $caracteristica as $key => $value)
                        <tr data-entry-id="{{ $value->id }}">
                         
                            <td>
                                {{ $value->id ?? '' }}
                            </td>
                            <td>
                                {{ $value->tipo ?? '' }}
                            </td>
                            <td>
                                {{ $value->description ?? '' }}
                            </td>
                            <td>                            

                             
                                    <a class="btn btn-xs btn-info" href="#edit{{$value->id}}" data-toggle="modal">
                                        {{ trans('global.edit') }}
                                    </a>
                            

                              
                                    <form action="{{ route('admin.caracteristica_quotes.destroy', $value->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <input type="submit" class="btn btn-xs btn-danger" value="{{ trans('global.delete') }}">
                                    </form>
                            

                            </td>

                        </tr>


<!-- Modal EDITAR -->
<div class="modal fade" id="edit{{$value->id}}" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                        
                        <h3>Nueva Descripción</h3>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="form" action="{{route('admin.caracteristica_quotes.update', [$value->id])}}" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('PUT')}} 
               <div class="form-group">
               	<label for="tipo">Para tipo de producto: </label>
               	<input type="text" name="tipo" class="form-control" value="{{old('tipo', isset($value) ? $value->tipo : '')}}">
               </div>
               <div class="form-group">
               	<label for="description">Descripción: </label>
               	<textarea name="description" class="form-control">{{old('description', isset($value) ? $value->description : '')}}</textarea> 
               </div>

               <div class="modal-footer">
               	<input type="submit" class="btn btn-primary" value="Modificar">
               </div>						

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>  

<!-- Fin modal editar -->


                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="row">
	<!-- Modal CREAR -->
<div class="modal fade" id="new" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                        
                        <h3>Nueva Descripción</h3>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="form" action="{{route('admin.caracteristica_quotes.store')}}" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('POST')}} 
               <div class="form-group">
               	<label for="tipo">Para tipo de producto: </label>
               	<input type="text" name="tipo" class="form-control">
               </div>
               <div class="form-group">
               	<label for="description">Descripción: </label>
               	<textarea name="description" class="form-control"></textarea> 
               </div>

               <div class="modal-footer">
               	<input type="submit" class="btn btn-primary" value="Crear">
               </div>						

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>  

<!-- Fin modal crear -->
</div>

@endsection