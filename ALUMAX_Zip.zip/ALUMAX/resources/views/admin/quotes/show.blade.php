@extends('layouts.admin')
@section('content')

<?php
use App\Quotation;
use App\ServiciosQuotation;
use App\CaracteristicasQuotation;
use App\CaracteristicaQuotes;
use App\ISV;
use Symfony\Component\HttpFoundation\Response;

if (empty($_GET["id"])) {
    exit;
}
 

if(!Quotation::find($id)){
    echo (Response::HTTP_FORBIDDEN.' | Forbidden');
    return back();
}else{
    $cotizacion = Quotation::find($id)->get('id');

}
if (!$cotizacion) {
    exit("No existe la cotización");
}
$quotation_id = $_GET['id']; 
$servicios = ServiciosQuotation::all()->where('quotation_id', $quotation_id);

$caracteristicas = CaracteristicasQuotation::all()->where('quotation_id', $quotation_id);
$cotizacion = Quotation::all()->where('id', $quotation_id);
$caracteristica_quotes = CaracteristicaQuotes::all();
?>
<div id="app">     
    <div class="row">
        <div class="col-sm">
            <div class="row">
                <div class="col-sm-8">
                    <table class="table table-striped table-hover datatable">
                    <td width="90%">
                        <h3>Productos cotización #{{$id}}</h3></td>
                    <td width="10%">
                        <a class="btn btn-primary"href='/admin/imprimir/?id=<?php echo $quotation_id ?>' onclick="window.open(this.href, 'Cotización#{{$id}}', 'width=700, height=700,');return false;"><i class="fa fa-file-pdf" aria-hidden="true"></i> PDF</a></td>
                    </table>

                    <div class="alert alert-info">
                        <p>Añada productos que tienen un precio, al final se calcularán los totales</p>
                    </div>
                    <div class="row">
                        <div class="col-sm">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover ">
                                    <thead>
                                    <tr>                             
                                        <th>Cantidad</th>
                                        <th class="text-center">Producto</th>
                                        <th class="text-nowrap">Precio Unitario</th>
                                        <th class="text-nowrap">Precio Total</th>
                                        <th>Editar</th>
                                        <th>Eliminar</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $subTotal = 0.00;
                                    $descuento = 0.00;
                                    $TOTAL = 0.00;
                                    $pre_tot = 0.00;
                                    $isv= 0.00;

                                    ?>
                                    <?php 
                                    foreach ($servicios as $servicio) {
 
                                        ?>
                                        <tr>  
                                            <td class="text-center">{{$servicio->cantidad}}</td>
                                            <td class="text-nowrap"><?php echo htmlentities($servicio->servicio)." de "."$servicio->ancho"."x"."$servicio->alto"." m" ?></td>
                                            

                                            <td class="text-right"><?php 
                                            $unitario = $servicio->costo;
                                            $pre_unit= round($unitario *(1/1.15), 2);
                                             ?>{{number_format($pre_unit, 2)}}

                                            </td>
                                            <td class="text-right"><?php 
                                            $cant= $servicio->cantidad;
                                            $pre_tot= round($pre_unit * $cant, 2);
                                            $subTotal += $pre_tot;
                                             ?>{{number_format($pre_tot, 2)}}
                                            </td>

                        <td>
                            <a class="btn btn-warning"
                               href="#edit{{$servicio->id}}" data-toggle="modal">
                                <i class="fa fa-edit"></i>
                            </a>
                              
                
                        </td>
                                <td>                                                           
                                    <form action="{{ route('admin.quotes.destroy', $servicio->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <button type="submit" class="btn btn btn-danger"> <i class="fa fa-trash"></i> </button>
                                    </form>
                                </td>
                                        </tr>
                                         <!-- MODAL EDITAR-->
                            <div class="modal fade" id="edit{{$servicio->id}}" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1>Editar Artículo</h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="{{route('admin.quotes.update', $servicio->id)}}" method="POST">
                                                 @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('PUT')}}
                                                 <div class="form-group">
                                                   
                                               </div>
                                            <div class="form-group">

                                                <label for="servicio">Producto: </label>
                                                <input type="text" class="form-control" name="servicio" value="{{old('servicio', isset($servicio)? $servicio->servicio: '') }}" required>
                                         
                                            </div>
                                             <div class="form-group">
                            <label for="Medidas">Medidas: (metros)</label><br>
                              <div class="input-group">
                            <input name="ancho" autocomplete="off" required type="number" step="0.01" min= '0.40' class="form-control" 
                                   id="ancho" placeholder="Ancho" value="{{ old('ancho', isset($servicio) ? $servicio->ancho: '') }}"><span class="input-group-addon"><strong> x </strong></span><input name="alto" autocomplete="off" required type="number" step="0.01" min= '0.30'id="alto" placeholder="Alto" class="form-control" value="{{old('alto', isset($servicio) ? $servicio->alto: '')}}">
                               </div>
                        </div>
                                             <div class="form-group">

                                                <label for="cantidad">Cantidad: </label>
                                                <input type="number" class="form-control" min="1" name="cantidad" value="{{ old('cantidad', isset($servicio) ? $servicio->cantidad : '') }}" required>                                         
                                            </div>
                                            <div class="form-group">
                                                <label for="costo">Precio:</label>
                                                <input type="number" id="txtMonto" class="form-control" min="100" step="0.01" name="costo" value="{{old('costo', isset($servicio)? $servicio->costo: '')}}">      
                                            </div>
                                                <div class="form-group">
                                                    
                                                </div>  

                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="Guardar cambios">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                    <!-- FIN MODAL -->
                                    <?php } ?>
 
                                    </tbody>

                                    <tbody>
                                        
                                    <tr>
                                    	<td colspan="2"></td>
                                        <td><strong>Sub-Total L.</strong></td>
                                        <td class="text-right"><strong>{{number_format($subTotal, 2)}} 
                                        </strong></td>
                                              
                                    </tr>
                                    <tr>
                                        <td colspan="2"></td>
                                        <td><strong>Descuento L.</strong></td>
                                        <td class="text-right"><strong>

                                            @foreach($cotizacion as $desc)
                                            <?php  $descuento = number_format($desc->descuento, 2);?>
                                            {{$descuento}}
                                                </strong></td>
                                              @endforeach
                                         
                                        <td colspan="2" align="center">
                                           <a class="btn btn-secondary"
                                           href="#edit{{$quotation_id}}" data-toggle="modal">       
                                                <i class="fas fa-hand-holding-usd"> Aplicar desc.</i></a>
                                        </td>
                        
               
                                    </tr>
                                    <tr>
                                    	<td colspan="2"></td>
                                        <td>15% I.S.V. L.</td>
                                        <td class="text-right"><strong><?php
                                            $isv_q=ISV::all();
                                            
                                        foreach ($isv_q as $value) {
                                            $imp=($value->isv ??'')/100;   

                                        $isv = round($subTotal * $imp, 2);

                                        }
                                         ?> {{number_format($isv, 2)}}
                                                </strong></td>
                                              
                                    </tr>
                                    
                                     <tr>
                                    	<td colspan="2"></td>
                                        <td class="active"><strong>TOTAL L.</strong></td>
                                        <td class="text-right"><strong><?php
                                        $TOTAL = $subTotal - $descuento + $isv;
                                        ?> {{number_format($TOTAL, 2)}}
                                                </strong></td>
                                              
                                    </tr>
                              
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <?php 
use App\Product;

 $name= DB::select('SELECT * from products');
 $pro = $name;
?>  
                <div class=" card col-sm-4">
                    <div class="card-body">
                    <h3>Agregar productos</h3> 
                    <form method="get" action="{{route('admin.quotes.create'), $quotation_id}}">
                        <input type="hidden" name="quotation_id" value="{{$quotation_id}}">
                     
                        <div class="form-group">
                            <label for="servicio">Producto:</label>                            
                	<select name="servicio" id="servicio" required autofocus="true" class="form-control" value="Seleccione" required>
                    
	                   @foreach($pro as $dato) 
	                       
	                        <option>{{ $dato->name }}</option>
	                       
	                   @endforeach
                	</select>      
                        </div>
                        <div class="form-group">
                            <label for="costo">Precio:</label>
                            <input name="costo" autocomplete="off" required type="number" class="form-control" step="0.01" min= '100' id="costo" placeholder="Lps.">
                        </div>
                        <div class="form-group">
                            <label for="Medidas">Medidas: (metros)</label><br>
                              <div class="input-group">
                            <input name="ancho" autocomplete="off" required type="number" step="0.01" min= '0.40' class="form-control" 
                                   id="ancho" placeholder="Ancho "><span class="input-group-addon"> x </span><input name="alto" autocomplete="off" required type="number" step="0.01" min= '0.30'
                                   id="alto" placeholder="Alto" class="form-control">
                               </div>
                        </div>
                        <div class="form-group">
                            <label for="servicio">Cantidad:</label>
                            <input autofocus name="cantidad" autocomplete="off" required type="number"
                                   class="form-control" id="servicio" placeholder="Cantidad" min="1">
                        </div>
                       

                        <button type="submit" class="btn btn-primary">AGREGAR</button>

                    <a style="margin-left:20px;" class="btn btn-default" href="{{route('admin.quotes.index') }}">
                        {{ trans('global.back_to_list') }}
                    </a>
           
                    </form>
                
                    <hr>
                       @foreach($cotizacion as $desc)


                    <!-- MODAL DESCUENTO-->
                            <div class="modal fade" id="edit{{$quotation_id}}" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-body">
                                         <div class="card">                                            
                                            <div class="card-body">
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                                </button>
                                                <form id="formAP" action="{{ route('admin.quotes.update', [$quotation_id]) }}" method="POST">
                                                 @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('PUT')}}
                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
 
                                               </div>
                
                                                <div class="form-group">
                                                    <label for="descuento">Descuento: L.</label>
                                                    <input class="form-control" type="number" step="0.01" min="0" name="descuento" value="{{ old('descuento', isset($desc) ? $desc->descuento : '') }}">
                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="Aplicar">
                                                </div>
                                            </div>  
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- fin modal editar -->
                            @endforeach

                    </div>
             </div>
            </div>
        </div>    
    </div>
</div>
            <hr>
<!-- ****************************CARACTERÍSTICA**************************************************** -->
            <div class="row">
                <div class="col-sm-8">
                    <h3>Características</h3>
                    <div class="alert alert-info">
                        <p>Información que ayudan a describir la cotización</p>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>Característica</th>
                                <th>Editar</th>
                                <th>Eliminar</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            foreach ($caracteristicas as $caracteristica) {
                                ?>
                                <tr>
                                    <td><?php echo htmlentities($caracteristica->caracteristica); ?></td>
                                    <td>
                                        <a
                                                class="btn btn-warning"
                                                href="#editar{{$caracteristica->id}}" data-toggle="modal">
                                            <i class="fa fa-edit"></i>
                                        </a>
                            <!-- MODAL EDITAR-->
                            <div class="modal fade" id="editar{{$caracteristica->id}}" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1>Editar Característica</h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formC" action="{{route('admin.quotes.update', $caracteristica->id)}}" method="POST">
                                                 @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('PUT')}}
                                                 <div class="form-group">
                                                   
                                               </div>
                                            <div class="form-group">

                                                <label for="servicio">Características: </label>
                                                <textarea type="text" class="form-control" name="caracteristica" value="{{old('caracteristica', isset($caracteristica)? $caracteristica->caracteristica: '') }}" required> {{old('caracteristica', isset($caracteristica)? $caracteristica->caracteristica: '') }}                                       </textarea>
                                            </div>                    
                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="Guardar cambios">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <!-- fin modal editar -->


                                    </td>
                                    <td>
                                        <form action="{{ route('admin.quotes.destroy', $caracteristica->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <button type="submit" class="btn btn btn-danger"> <i class="fa fa-trash"></i> </button>
                                    </form>
                                    </td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class=" card col-sm-4">
                    <div class="card-body">
                    <h3>Agregar característica</h3>
                    <form method="get" action="{{route('admin.quotes.create'), $quotation_id}}">

                        <input type="hidden" name="quotation_id" value="<?php echo $_GET["id"] ?>">
                      
                        <div class="form-group">
                            <label for="caracteristica">Característica</label>
                            <textarea name="caracteristica" autocomplete="off" required class="form-control"
                                   placeholder="Algo que ayude a describir la cotización."></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Guardar</button>
                        <a style="margin-left:20px;" class="btn btn-default" data-toggle="modal" data-target="#ayuda">
                        Ayuda
                    </a>
                    </form>
                    <hr>
                    </div>
                   </div>
            </div>
    </div>

<!-- MODAL AYUDA******************************************************************* -->
<div class="modal fade" id="ayuda" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Sugerencias</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            @foreach($caracteristica_quotes as $car_quo)
        <label>{{$car_quo->tipo}}</label>
        <p>{{$car_quo->description}}</p>    
            @endforeach
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
      </div>
    </div>
  </div>
</div>

<!-- FIN MODAL AYUDA -->
@endsection
@section('scripts')
@parent



@endsection



