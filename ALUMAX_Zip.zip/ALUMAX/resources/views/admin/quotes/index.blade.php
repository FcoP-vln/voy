@extends('layouts.admin')
@section('content')

<?php
   use App\ServiciosQuotation;
   use APP\Cost;

use App\Quotation;
use App\Client;
use App\ClientStatus;
$cotizaciones = Quotation::all()->sortBy('id');
$clientes = Client::all()->sortByDesc('id');
$statuses = ClientStatus::all();
?>

<div class="row">
    <div class="col-sm">
        <h1>{{trans('cruds.quotes.title')}}</h1>
        
    </div>
</div>

<div class="row">
    <div class="col-sm">
        <p>
            <a href="#new" class="btn btn-success" data-toggle="modal">
                <i class="fa fa-plus"></i> {{trans('cruds.quotes.fields.new')}}
            </a>
        </p>   
    </div>
   
    
    
</div>

<div class="card">
    <div class="card-header">
       {{(trans('cruds.quotes.title'))}} - {{ trans('global.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Quotation">
                <thead>
                <tr>
                    <th width="10"></th>
                    <th>#</th>
                    <th>{{trans('cruds.quotes.fields.client')}}</th>
                    <th>{{trans('cruds.quotes.fields.state')}}</th>
                    <th>{{trans('cruds.quotes.fields.date')}}</th>
                    <th>{{trans('cruds.quotes.fields.details')}}</th>
                    <th>{{trans('cruds.quotes.fields.buy')}}</th>
                    <th>{{trans('global.datatables.print')}}</th>
                    <th>{{trans('global.edit')}}</th>
                    @can('quotes_delete')
                    <th>{{trans('global.delete')}}</th>
                    @endcan
                </tr>
                </thead>
                <tbody>
                @foreach ($cotizaciones as $key=>$cotizacion)
                        <tr data-entry-id="{{ $cotizacion->id }}">
                        <td>
                            
                        </td>
                        <td>{{$cotizacion->id ?? ''}}   
                        </td>
                        <td><?php echo htmlentities($cotizacion->client->first_name) ??''?> <?php echo htmlentities($cotizacion->client->last_name ?? '') ?>     
                        </td>
                        <td><?php echo htmlentities($cotizacion->description ?? '') ?></td>
                        <td>{{ date('d-m-Y', strtotime($cotizacion->quotation_date)) ?? '' }}</td>
                        <td align="center">
                            <a class="btn btn-info"
                               href="{{route('admin.quotes.show', [$cotizacion->id]) }}/?id=<?php echo $cotizacion->id ?>" >
                                <i class="fa fa-info"></i>
                            </a>
                        </td>
                        <td>
                             <a class="btn btn-secondary"
                               href="{{route('admin.quotes.edit', [$cotizacion->id]) }}/?id=<?php echo $cotizacion->id ?>" >
                                <i class="fas fa-shopping-basket"></i>
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-primary"
                                href='/admin/imprimir/?id=<?php echo $cotizacion->id ?>' target="_blank">
                                <i class="fa fa-print"></i>
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-warning"
                               href="#edit{{$cotizacion->id }}" data-toggle="modal">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td>
                            @can('quotes_delete')
                        <td>
                            <form action="{{ route('admin.quotes.destroy', $cotizacion->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <button type="submit" class="btn btn btn-danger"> <i class="fa fa-trash"></i> </button>
                            </form>
                        </td>    
                             @endcan
                    </tr>
                                     
                                              <!-- MODAL EDITAR-->
                            <div class="modal fade" id="edit{{$cotizacion->id }}" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1>{{trans('global.edit')}} {{trans('cruds.quotes.title_singular')}} #{{$cotizacion->id}}</h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="{{ route('admin.quotes.update', [$cotizacion->id]) }}" method="POST">
                                                 @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('PUT')}}
                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
                                               </div>
                                               <div class="form-group">

                                                <label for="client_id">{{trans('cruds.quotes.fields.client')}}:</label>
                                                
                                                <select required class="form-control" name="client_id" id="client_id">
                                                    <?php foreach ($clientes as $cliente) { ?>
                                                        <option value="<?php echo $cliente->id ?>" {{ (isset($cotizacion) && $cotizacion->client ? $cotizacion->client->id : old('client_id')) == $cliente->id  ? 'selected' : '' }}>

                                                            <?php echo htmlentities($cliente->first_name) ?> <?php echo htmlentities($cliente->last_name) ?></option>
                                                        <?php } ?>
                                                    </select>
                                                 

                                            </div>
                                            <div class="form-group">
                                                <label for="description">{{trans('cruds.quotes.fields.state')}}:</label>
                                                
                                                <select autofocus required class="form-control" name="description" required>
                                                    <?php foreach ($statuses as $status) { ?>
                                                        <option value="<?php echo $status->name ?>" {{ (isset($cotizacion) && $cotizacion->description ? $cotizacion->description : old('description')) == $status->name  ? 'selected' : '' }}>

                                                            {{$status->name}}</option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                                <div class="form-group">
                                                    <label for="quotation_date">{{trans('cruds.quotes.fields.date')}}:</label>
                                                    <input value="{{ old('quotation_date', isset($cotizacion) ? $cotizacion->quotation_date : '') }}" name="quotation_date" autocomplete="off" required type="date"
                                                    class="form-control" id="fecha" >
                                                </div>  

                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="{{trans('cruds.receipts.fields.save_changes')}}">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <!-- fin modal editar -->
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row">
    <!-- MODAL CREAR-->
  <div class="modal fade" id="new" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                        <?php $new = $cotizacion->id ?? '';
                              $nueva= $new + 1; 
                         ?>
                        <h1>{{trans('cruds.quotes.fields.new')}} #{{$nueva}}</h1>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="formAP" action="#" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('POST')}}
               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
            </div>
            <div class="form-group">
             <input type="hidden" name="quotation_id" value="{{$nueva}}">  
            </div>
               <div class="form-group">

                <label for="client_id">{{trans('cruds.quotes.fields.select')}}:</label>
                <select required class="form-control" name="client_id" id="client_id">
                    <?php foreach ($clientes as $cliente) { ?>
                        <option value="<?php echo $cliente->id ?>"><?php echo htmlentities($cliente->first_name) ?> <?php echo htmlentities($cliente->last_name) ?></option>
                    <?php } ?>
                </select>
             
              </div>
              <div class="form-group">
                <label for="description">{{trans('cruds.quotes.fields.state')}}:</label>
               
               <select required class="form-control" name="description" required>
                    <?php foreach ($statuses as $status) { ?>
                        <option value="<?php echo htmlentities($status->name)?>">{{$status->name}}</option>
                    <?php } ?>
                </select>
                </div>
              <div class="form-group">
                <label for="quotation_date">{{trans('cruds.quotes.fields.date')}}:</label>
                <input value="<?php echo date("Y-m-d") ?>" name="quotation_date" autocomplete="off" required type="date"
                       class="form-control" id="fecha">
            </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="{{trans('global.create')}}">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>


@endsection
@section('scripts')
@parent
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('quotes_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('admin.quotes.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      }); 

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  $('.datatable-Quotation:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>
@endsection
