@extends('layouts.admin')
@section('content')
<?php
   use App\ServiciosQuotation;
   use APP\Cost;

use App\Quotation;
use App\Client;
use App\ClientStatus;
$quotation_id = $_GET['id']??''; 
$cotizaciones = Quotation::all()->where('id', $quotation_id);

?>


 @foreach ($cotizaciones as $key=>$cotizacion) 

                            <div class="card">
                                    <div class="card-body">
                                        <div class="card-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1>Compra requerida para Cotización #{{$cotizacion->id}}</h1>
                                                </div>
                                            </div>
                            
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="{{route('admin.sobrantes.store')}}" method="POST">
                                                 @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('POST')}}
                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
                                                  <!--  <input type="hidden" name="quotation_id" value="{{$cotizacion->id ?? ''}}"> -->
                                               </div>
                                               <div class="form-group">

                                                <label for="client_id">Producto:</label>
                                <?php 
                          
                                $servicios = ServiciosQuotation::all()->where('quotation_id', $cotizacion->id);
                                

                                 ?>                
                                                
                                          <?php foreach ($servicios as $ser) { ?>
                                                        
                                                      <h4>{{$ser->servicio}} ({{$ser->cantidad}}) - {{$ser->ancho}} x {{$ser->alto}} m</h4>
                                                      <table border="2" class="table table-bordered table-striped">
                                                      	  <tr>
                                                            	<th>Material</th>
                                                            	<th>Cantidad a utilizar (metros)</th>
                                                            	<th>Cantidad a comprar(lance/rollo)</th>
                                                            	<th>Sobrante (metros)</th>
                                                              <th>Agregar a Inventario</th>
                                                            </tr>  

                                                      <?php  
                                                        $nom=$ser->servicio;
                                                        $name= DB::select('SELECT * from products where name='.'"'.$nom.'"');
                                                        $pro = $name;

                                                        foreach ($pro as $key => $dato) {
                                                          $p_id= $dato->id;                                   

                                                                   $materiales = DB::select('SELECT * from cost_product where product_id='.$p_id);
                                                          ;
                                                          foreach ($materiales as $key => $material) {
                                                            $mat_id=$material->cost_id;

                                                            $mat_nom = DB::select('SELECT * from costs where id='.$mat_id);
                                                            foreach ($mat_nom as $key => $mate) {?>
                                                         <!--  <input type="hidden" name="material[]" value="{{$mate->name ?? ''}}"> -->
 
<tr>
                                                            <td> {{$mate->name}}</td>
                                                            <td class="text-center">
                                                            	<?php 
                                                            	$ancho = $ser->ancho;
                                                            	$alto = $ser->alto;
                                                            	$ancho_re= $mate->width_required;
                                                            	$alto_re= $mate->high_required;
                                                            	$cant = $ser->cantidad;
                                                            	 $larg = $mate->longsize;
                                                            	 $stot1= $ancho*$ancho_re;
                                                            	 $stot2= $alto*$alto_re;
                                                            	 $stotal = $stot1+$stot2;
                                                            	 $total=$stotal*$cant;
                                                            	?>
                                                            	{{$total}}

                                                            </td>
                                                            <td class="text-center">
                                                            	<?php $comprar=($total*100)/$larg;?>
                                                            	{{ceil($comprar)}}		
                                                           	</td>
                                                            <td class="text-center"><?php 
                                                            	$ctd_exacta = $comprar;
                                                            	$larg=ceil($comprar)*$mate->longsize;
                                                            	$lance= $larg/100;
                                                            	$sobrante=$lance - $total;

                                                             ?>{{$sobrante}}</td>
                                                           <!--   <input type="hidden" name="cantidad" value="{{$sobrante ?? ''}}"> -->
                                                             <td>
                                                               <form action="{{ route('admin.sobrantes.store')}}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                                                @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('POST')}}
                                        <input type="hidden" name="quotation_id" value="{{$cotizacion->id}}">
                                        <input type="hidden" name="material" value="{{ $mate->name }}">
                                         <input type="hidden" name="cantidad" value="{{ $sobrante }}">
                                        <input type="submit" class="btn btn-xs btn-primary" value="{{ trans('global.add') }}">
                                          
                                    </form>
                                                                      
                                                             </td>
                                                         </tr>
                                                             
                                                            <?php  }
                                                            
                                                          }


                                                 
                                                        }

                                                      ?>  
                                                      </table>

                                          <?php } ?>
                                                       
                                                         
                                           

                                            </div>
                                            

                                                <div class="modal-footer">
                                                  <!--   <input type="submit" class="btn btn-primary" value="Guardar materiales sobrantes"> -->
                                                      <a style="margin-left:20px;" class="btn btn-default" href="{{route('admin.quotes.index') }}">
                        {{ trans('global.back_to_list') }}
                    </a>

                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
          
@endforeach

@endsection