
 <title>{{ trans('panel.site_title') }}</title>
  
<?php
use App\Quotation;
use App\ServiciosQuotation;
use App\CaracteristicasQuotation;
use App\Client;
use App\Invoice;
use App\Cai;
use Symfony\Component\HttpFoundation\Response;
setlocale(LC_TIME, 'es_ES', 'esp_esp'); 

$cai = Cai::all();
$cotizaciones = Quotation::all();
$id= $_GET["id"];
if (empty($_GET["id"])) {
    exit;
}
 

if(!Invoice::find($id)){
    echo (Response::HTTP_FORBIDDEN.' | Forbidden');
    return back();
}else{
    $factura_date = Invoice::find($id)->where('id', $id)->get('invoice_date');
    $cliente_f= Invoice::find($id)->where('id', $id)->get('client');
    $rtn = Invoice::find($id)->where('id', $id)->get('rtn');
    // $cotizacion = Invoice::find($id)->where('id', $id)->get('quotation_id');
}
// if (!$cotizacion) {
//     exit("No existe la cotización");
// }
$quotation_id = Invoice::find($id)->where('id', $id)->get();
foreach ($quotation_id as $key => $value) {
	$quo_id = $value->quotation_id;
}
$servicios = ServiciosQuotation::all()->where('quotation_id', $quo_id);


$descuent = Quotation::all()->where('id', $quo_id);
?>
<meta http-equiv="content-type" content="text/html; utf-8">
<div>
        <div class="col-sm" align="center">
        	<p style="font-size: xx-small;"><img src="./img/LOGO.png" style="max-height: 67px;"><br>INVERSIONES DIVERSAS DE ORIENTE S. DE R.L.<br>
        		Col. Villa Vieja 3.5 km carretera a Danlí, frente a Yonker Jireh, Tegucigalpa M.D.C.<br>
        		Tel. :(504) 2243-2948 / 3362-2139, Correo: alumax.hn@gmail.com<br>
        	R.T.N. 08019017957660 </p>
        </div>

    <div class="row">
        <div class="col-12">
        	<br>
             <div>
             <strong style="font-size: small; margin-left: 35px;">FACTURA: 000-001-01-00000{{$id}}</strong>

           <?php $R = ""; ?>
             @foreach($factura_date as $factura)
             <p style="font-size: x-small; margin-left: 35px;">Fecha de emisión: {{strtolower(strftime("%d de %B de %Y", strtotime($factura->invoice_date)))}}
             	@endforeach<br><b>

             		CLIENTE: 
             		<?php foreach ($cliente_f as $key => $value): ?>
             			{{strtoUpper($value->client)}}
             			<?php endforeach ?></b>

                   
                   
                 @foreach ($rtn as $key => $val)
                  <?php if($val->rtn == null){
                      $R = " ";
                  }else{
                        $R ="R.T.N: ";
                  } ?>

                     {{$R}} {{$val->rtn}}
                   @endforeach</p>
                  

            



             </div>
                    <div class="row">
                                <table align ="center" border="1"cellspacing="0" style="font-size: x-small">
                                    <thead style="background-color: #C0C0C0;">
                                    <tr>
                                        <th width="10%">Cantidad</th>
                                        <th width="400px">Producto</th>
                                        <th width="70px">Precio Unitario</th>
                                        <th width="70px">Precio Total</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody cellspacing="0" cellpadding="5">
                                    <?php
                                    $subTotal = 0.00;
                                    $descuento = 0.00;
                                    $TOTAL = 0.00;
                                    $pre_tot = 0.00;
                                    $isv= 0.00;

                                    ?>
                                    <?php 
                                    foreach ($servicios as $servicio) {
 
                                        ?>
                                        <tr>
                                            <td align="center" height= "30px" style="border-bottom: dotted;">{{$servicio->cantidad}}</td>
                                            <td cellpadding="5"  style="border-bottom: dotted;"><?php echo htmlentities($servicio->servicio)." de "."$servicio->ancho"."x"."$servicio->alto"." m" ?></td>
                                            

                                            <td align="right" height= "30px" style="border-bottom: dotted;" ><?php 
                                            $unitario = $servicio->costo;
                                            $pre_unit= round($unitario *(1/1.15), 2);
                                             ?>{{number_format($pre_unit, 2)}}

                                            </td>
                                            <td align="right" height= "30px"  style="border-bottom: dotted;"><?php 
                                            $cant= $servicio->cantidad;
                                            $pre_tot= round($pre_unit * $cant, 2);
                                            $subTotal += $pre_tot;
                                             ?>{{number_format($pre_tot, 2)}}
                                            </td>                   
                                        </tr>
                  
                                    <?php } ?>
 
                                    </tbody>

                                    <tbody>
                                        
                                    <tr>
                                    	<td height="1%" colspan="2" rowspan="2" align="center" style="border-top: double;"><label style="color:#536197;"><b>Garantía de un año</b></label></td>
                                        <td align="right" style="border-top: double;"><strong>Sub-Total L.</strong></td>
                                        <td align="right" style="border-top: double; "><strong>{{number_format($subTotal, 2)}} 
                                                </strong></td>
                                              
                                    </tr>
                                    <tr >
                                    
                                        <td align="right" style="font-size: xx-small; border-top: medium groove;">Desc. y Rebaja L.</td>
                                        <td align="right" style="border-top: medium groove;"><strong> 
   
                                            @foreach($descuent as $desc)
                                            <?php  $descuento = number_format($desc->descuento, 2);?>
                                            {{$descuento}}
                                                </strong></td>
                                              @endforeach


                                                </strong></td>
                                              
                                    </tr>
                                     <tr>
                                    	<td colspan="2" rowspan="7" valign="left" style="border-top: medium groove;">
                                    		<b>
                                    			<?php foreach ($cai as $cai) { ?>
                                    			Rango Autorizado:<br>
                                          {{$cai->rango_desde}} a la<br>
                                          {{$cai->rango_hasta}}<br>
                                          CAI: {{$cai->cai}}<br>
                                          Fecha límite de emisión: {{ date('d-m-Y', strtotime($cai->fecha_limite))}}
                                          <br>
                                    			<?php } ?>
                                    		</b>
                                    	</td>
                                        <td align="right" style="font-size: xx-small; border-top: medium groove;">Importe Exonerado L.</td>
                                        <td align="right" style="border-top: medium groove;"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>
                                     <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">Importe Exento L.</td>
                                        <td align="right"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>
                                     <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">Importe Gravado 15% L.</td>
                                        <td align="right"><strong>{{number_format($subTotal, 2)}} 
                                                </strong></td>
                                              
                                    </tr>
                                    <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">Importe Gravado 18% L.</td>
                                        <td align="right"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>

                                    <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">15% I.S.V. L.</td>
                                        <td align="right"><strong><?php
                                        $isv = round($subTotal * 0.15, 2);
                                        ?> {{number_format($isv, 2)}}
                                                </strong></td>
                                              
                                    </tr>

                                     <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">18% I.S.V. L.</td>
                                        <td align="right"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>
                                    
                                     <tr>
                                    	
                                        <td align="right" style="border-top: medium solid;"><strong>TOTAL L.</strong></td>
                                        <td align="right" style="border-top: medium solid;"><strong><?php
                                        $TOTAL = $subTotal -$descuento + $isv;
                                        ?> {{number_format($TOTAL, 2)}}
                                                </strong></td>
                                              
                                    </tr>
                                    </tbody>
                                </table>
                    </div>

                </div>
    </div>
    <div class="row">
        <div class="col-sm">
          <p align="center" style="font-size: small">
          	"La factura es beneficio de todos, exíjala"
          </p>  
        </div>
    </div>
    <br><br><br><br><br>
    <p style="color: #818181; font-size: small" align="center">Recibí conforme y a satisfacción los productos, obras y/o servicios de ALUMAX</p>
    <br><br>
    
    <div class="footer">
        <div class="col-lg" >
          <table align="center" style="color: #818181; font-size: small">
          		<tr>
          		<th width="220px"></td>
          		<th width="220px"></td>
          		<th width="220px"></td>
          	</tr>
          	<tr>
          		<td><hr width="80%" vertical-align=top></td>
          		<td><hr width="80%"></td>
          		<td><hr width="80%"></td>
          	</tr>
          	<tr >
          		<td align="center">Nombre</td>
          		<td align="center">Número de identidad</td>
          		<td align="center">Firma</td>
          	</tr>
          </table>
        </div>
    </div>


    <div class="row">
        <div class="col-sm">
            <br>
        </div>
    </div>
</div>