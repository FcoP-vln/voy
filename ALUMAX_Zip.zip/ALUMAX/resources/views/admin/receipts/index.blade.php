@extends('layouts.admin')
@section('content')

<?php
use App\Quotation;
use App\Client;
use App\ClientStatus;
use App\Receipt;
$cotizaciones = Quotation::all()->sortBy('id');
$clientes = Client::all()->sortByDesc('id');
$statuses = ClientStatus::all();
$recibos = Receipt::all()->sortBy('id');
?>

<div class="row">
    <div class="col-sm">
        <h1>{{trans('cruds.receipts.title')}}</h1>
        
    </div>
</div>

<div class="row">
    <div class="col-sm">
        <p>
            <a href="#new" class="btn btn-success" data-toggle="modal">
                <i class="fa fa-plus"></i> {{trans('cruds.receipts.fields.new')}}
            </a>
        </p>   
    </div>
   
    
    
</div>

<div class="card">
    <div class="card-header">
       Recibos - {{ trans('global.list') }}
    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Receipts">
                <thead>
                <tr>
                    <th width="10"></th>
                    <th>{{trans('cruds.receipts.title_singular')}} #</th>
                    <th>{{trans('cruds.receipts.fields.client')}}</th>
                    <th>{{trans('cruds.receipts.fields.initial')}}</th>
                    <th>{{trans('cruds.receipts.fields.payment')}}</th>
                    <th>{{trans('cruds.receipts.fields.balance')}}</th>
                    <th>{{trans('cruds.receipts.fields.date')}}</th>
                    <th class="text-center">{{trans('global.datatables.print')}}</th>
                    <th class="text-center">{{trans('global.edit')}}</th>
                    @can('quotes_delete')
                    <th class="text-center">{{trans('global.delete')}}</th>
                    @endcan
                </tr>
                </thead>
                <tbody> <?php 
                $saldo= 0.00;
                $si = 0.00;
                $abono= 0.00;
                 ?>
                @foreach ($recibos as $key=>$recibo)
                        <tr data-entry-id="{{ $recibo->id }}">
                        <td>
                            
                        </td>
                        <td>{{$recibo->id ?? ''}}   
                        </td>
                        <td>{{$recibo->nombre ?? ''}}   
                        </td>
                        <td>L. {{number_format($recibo->saldo_inicial,2)}}</td>
                        <td>L. {{number_format($recibo->abono, 2)}}</td>
                        <td align="center">
                            
                        	<!-- Cálculo de SALDO -->
                            <?php 
                            $si =  $recibo->saldo_inicial;
                            $abono = $recibo->abono;
                            $saldo =$si - $abono;

                            ?>
                            <b>L. {{number_format($saldo, 2)}}</b>

                        </td>
                        <td>{{ date('d-m-Y', strtotime($recibo->fecha)) }}</td>
                        <td align="center">
                            <a class="btn btn-primary"
                                href='/admin/imprimirR/?id=<?php echo $recibo->id ?>' target="_blank">
                                <i class="fa fa-print"></i>
                            </a>
                        </td>
                        <td align="center">
                            <a class="btn btn-warning"
                               href="#edit{{$recibo->id }}" data-toggle="modal">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td>
                            @can('quotes_delete')
                        <td align="center">
                            <form action="{{ route('admin.receipts.destroy', $recibo->id) }}" method="POST" onsubmit="return confirm('{{ trans('global.areYouSure') }}');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                        <button type="submit" class="btn btn btn-danger"> <i class="fa fa-trash"></i> </button>
                            </form>
                        </td>    
                             @endcan
                    </tr>
                                     <!-- MODAL EDITAR-->
                            <div class="modal fade" id="edit{{$recibo->id }}" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1>{{trans('global.edit')}} {{trans('cruds.receipts.title_singular')}} #{{$recibo->id}}</h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="{{ route('admin.receipts.update', [$recibo->id]) }}" method="POST">
                                                 @csrf
                                                 {{csrf_field()}}
                                                 {{method_field('PUT')}}
                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
                                               </div>
                                            <div class="form-group">
                                              <label for="nombre">{{trans('cruds.receipts.fields.client')}}:</label> 
                                              <input type="text" name="nombre" class="form-control" value= "{{old('nombre', isset($recibo) ? $recibo->nombre : '')}}">
  											</div>

                                            <div class="form-group">
                                                <label for="saldo_inicial">{{trans('cruds.receipts.fields.initial')}}:</label>
                                                
                                                <input type="text" name="saldo_inicial" class="form-control" value="{{old('saldo_inicial', isset($recibo) ? $recibo->saldo_inicial : '')}}">
                                            </div>
                                              <div class="form-group">
                                                <label for="abono">{{trans('cruds.receipts.fields.payment')}}:</label>
                                                <input type="text" name="abono" class="form-control" value="{{old('abono', isset($recibo) ? $recibo->abono: '')}}">
                                            </div>

                                            <div class="form-group">
                                            	<label for="descripcion">{{trans('cruds.receipts.fields.concept')}}:</label>
                                            	<textarea name="descripcion" class ="form-control" required>{{old('descripcion', isset($recibo) ? $recibo->descripcion : '')}}</textarea>
                                            </div>

                                                <div class="form-group">
                                                    <label for="fecha">{{trans('cruds.receipts.fields.date')}}:</label>
                                                    <input value="{{ old('fecha', isset($recibo) ? $recibo->fecha : '') }}" name="fecha" autocomplete="off" required type="date"
                                                    class="form-control" id="fecha" >
                                                </div>  

                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="{{trans('cruds.receipts.fields.save_changes')}}">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <!-- fin modal editar -->
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row">
    <!-- MODAL CREAR-->
  <div class="modal fade" id="new" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                    	@foreach($recibos as $recibo)
                        <?php $new = $recibo->id;
                              $nueva= $new + 1; 
                         ?>
                         @endforeach
                        <h1>{{trans('cruds.receipts.fields.new')}} #{{$nueva ?? ''}}</h1>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="formAP" action="#" method="POST">
               @csrf
               {{csrf_field()}}
               {{method_field('POST')}}
               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="{{auth()->user()->id}}" value="{{auth()->user()->id}}">  
            </div>        
               <div class="form-group">
                <label for="nombre">{{trans('cruds.receipts.fields.name')}}:</label>
                <input type="text" name="nombre" class ="form-control" placeholder="Ingrese nombre completo" required>
              </div>

              <div class="form-group">
                <label for="description">{{trans('cruds.receipts.fields.initial')}}:</label>
                <input type="number" step="0.1" min="1" name="saldo_inicial" class ="form-control" placeholder="Lps 0.00" required>
              </div>

              <div class="form-group">
                <label for="description">{{trans('cruds.receipts.fields.payment')}}:</label>
                <input type="number" step="0.1" min="1" name="abono" class ="form-control" placeholder="Lps 0.00" required>
              </div>

              <div class="form-group">
               <label for="descripcion">{{trans('cruds.receipts.fields.concept')}}:</label>
               <textarea name="descripcion" class ="form-control" required></textarea>
              </div>

              <div class="form-group">
                <label for="quotation_date">{{trans('cruds.receipts.fields.date')}}:</label>
                <input value="<?php echo date("Y-m-d") ?>" name="fecha" autocomplete="off" required type="date" class="form-control" id="fecha">
              </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="{{trans('cruds.receipts.fields.create')}}">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>
@endsection
@section('scripts')
@parent
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
@can('_delete')
  let deleteButtonTrans = '{{ trans('global.datatables.delete') }}'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "{{ route('admin.quotes.massDestroy') }}",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('{{ trans('global.datatables.zero_selected') }}')

        return
      }

      if (confirm('{{ trans('global.areYouSure') }}')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
@endcan

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 25,
  });
  $('.datatable-Receipts:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>
@endsection