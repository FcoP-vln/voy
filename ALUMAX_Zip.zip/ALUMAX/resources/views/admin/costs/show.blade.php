@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
       <label> {{ trans('global.show') }} {{ trans('cruds.cost.fields.name') }}</label>
    </div>

    <div class="card-body">
        <div class="mb-2">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            {{ trans('cruds.cost.fields.id') }}
                        </th>
                        <td>
                            {{ $cost->id }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            {{ trans('cruds.cost.fields.name') }}
                        </th>
                        <td>
                            {{ $cost->name }}
                        </td>
                    </tr>
                     <tr>
                        <th>
                            {{ trans('cruds.cost.fields.description') }}
                        </th>
                        <td>
                            {{ $cost->description }}
                        </td>
                    </tr>
                    <tr>
                        <th>
                            Para producto:
                        </th>
                        <td>
                           
                 <ul>
                    @foreach($cost->products as $name=> $products)
                        <li>{{ $products->name }}</li>
                    @endforeach
                </ul>
                        </td>
                        
                    </tr>
                    <tr>
                        <th>
                            Requerido en producto:
                        </th>
                        <td>
                            {{ $cost->width_required }} de ancho <b>+</b> {{ $cost->high_required }} de alto
                        </td>

                    </tr>
                         <tr>
                        <th>
                            Largo:
                        </th>
                        <td>
                            {{ $cost->longsize}} cm
                        </td>

                    </tr>
                </tbody>
            </table>
            <label>Precios: </label>
            

                  
            <br/>
            <table class="table table-bordered table-striped">
                	<tr>
                        <th>
                            {{ trans('cruds.cost.fields.white') }}
                        </th>
                        <th>
                            {{ trans('cruds.cost.fields.bronze') }}
                        </th>
                        <th>
                            {{ trans('cruds.cost.fields.wood') }}
                        </th>  
                        <th>
                            {{ trans('cruds.cost.fields.natural') }}
                        </th>                       
                    </tr>
                    <tr>
                    	<td>
                           Lps. {{ $cost->white }}
                        </td>
                    	<td>
                    		Lps. {{ $cost->bronze }}
                    	</td>
                    	<td>
                    		Lps. {{ $cost->wood }}
                    	</td>
                    	<td>
                    		Lps. {{ $cost->natural }}
                    	</td>
                    </tr>
               </table>
            <a style="margin-top:20px;" class="btn btn-default" href="{{ url()->previous() }}">
                {{ trans('global.back_to_list') }}
            </a>
        </div>

        <nav class="mb-3">
            <div class="nav nav-tabs">

            </div>
        </nav>
        <div class="tab-content">

        </div>
    </div>
</div>
@endsection
