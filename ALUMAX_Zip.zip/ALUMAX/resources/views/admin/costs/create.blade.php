@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.create') }} {{ trans('cruds.cost.title_singular') }}
    </div>

    <div class="card-body">
        <form action="{{ route("admin.costs.store") }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">
                <label for="name">{{ trans('cruds.cost.fields.name') }}*</label>
                <input type="text" id="name" name="name" class="form-control" value="{{ old('name', isset($cost) ? $cost->name : '') }}" required>
                @if($errors->has('name'))
                    <p class="help-block">
                        {{ $errors->first('name') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.name_helper') }}
                </p>
            </div>

            <div class="form-group {{ $errors->has('products') ? 'has-error' : '' }}">
                <label for="products">Para producto:
                    <span class="btn btn-info btn-xs select-all">{{ trans('global.select_all') }}</span>
                    <span class="btn btn-info btn-xs deselect-all">{{ trans('global.deselect_all') }}</span></label>
                <select name="products[]" id="products" class="form-control select2" multiple="multiple" required>
                    @foreach($products as $id => $products)
                        <option value="{{ $id }}" {{ (in_array($id, old('products', [])) || isset($cost) && $cost->products->contains($id)) ? 'selected' : '' }}>{{ $products }}</option>
                    @endforeach
                </select>
                @if($errors->has('products'))
                    <p class="help-block">
                        {{ $errors->first('products') }}
                    </p>
                @endif
            </div>



            <div class="form-group {{ $errors->has('white') ? 'has-error' : '' }}">
                <label for="white">{{ trans('cruds.cost.fields.white') }}*</label>
                <input type="number" min="0" id="white" name="white" class="form-control" value="{{ old('white', isset($cost) ? $cost->white : '') }}" step="0.01" required>
                @if($errors->has('white'))
                    <p class="help-block">
                       {{ $errors->first('white') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.white_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('bronze') ? 'has-error' : '' }}">
                <label for="bronze">{{ trans('cruds.cost.fields.bronze') }}*</label>
                <input type="number" min="0" id="bronze" name="bronze" class="form-control" value="{{ old('bronze', isset($cost) ? $cost->bronze : '') }}" step="0.01" required>
                @if($errors->has('bronze'))
                    <p class="help-block">
                       {{ $errors->first('bronze') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.bronze_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('wood') ? 'has-error' : '' }}">
                <label for="wood">{{ trans('cruds.cost.fields.wood') }}*</label>
                <input type="number" min="0" id="wood" name="wood" class="form-control" value="{{ old('wood', isset($cost) ? $cost->wood : '') }}" step="0.01" required>
                @if($errors->has('wood'))
                    <p class="help-block">
                       {{ $errors->first('wood') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.bronze_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('natural') ? 'has-error' : '' }}">
                <label for="natural">{{ trans('cruds.cost.fields.natural') }}*</label>
                <input type="number" min="0" id="natural" name="natural" class="form-control" value="{{ old('natural', isset($cost) ? $cost->natural : '') }}" step="0.01" required>
                @if($errors->has('natural'))
                    <p class="help-block">
                       {{ $errors->first('natural') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.natural_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('stock') ? 'has-error' : '' }}">
                <label for="stock">{{ trans('cruds.cost.fields.stock') }} inicial*</label>
                <input type="number" min="0" id="stock" name="stock" class="form-control" value="{{ old('stock', isset($cost) ? $cost->stock : '') }}"  required>
                @if($errors->has('stock'))
                    <p class="help-block">
                       {{ $errors->first('stock') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.stock_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('longsize') ? 'has-error' : '' }}">
                <label for="longsize">{{ trans('cruds.cost.fields.longsize') }}/cm</label>
                <input type="number" min="1" id="longsize" name="longsize" class="form-control" value="{{ old('longsize', isset($cost) ? $cost->longsize : '') }}" >
                @if($errors->has('longsize'))
                    <p class="help-block">
                       {{ $errors->first('longsize') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.longsize_helper') }}
                </p>
            </div>
            <div class="form-group {{ $errors->has('description') ? 'has-error' : '' }}">
                <label for="description">{{ trans('cruds.cost.fields.description') }}*</label>
                <textarea id="description" name="description" class="form-control " required>{{ old('description', isset($cost) ? $cost->description : '') }}</textarea>
                @if($errors->has('description'))
                    <p class="help-block">
                        {{ $errors->first('description') }}
                    </p>
                @endif
                <p class="helper-block">
                    {{ trans('cruds.cost.fields.description_helper') }}
                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="{{ trans('global.save') }}">
            </div>
        </form>
    </div>
</div>
@endsection