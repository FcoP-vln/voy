@extends('layouts.admin')
@section('content')

<h1>EDITAR 2</h1>


@endsection


























@endsection