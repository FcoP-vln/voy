<?php

return [
    'site_title' => 'Grupo ALUMAX',
    
];
