<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Binnacle extends Model
{
    use HasFactory;

     

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
            ];

    protected $fillable = [
        'user_id',
        'activity',
        'ip',
    ];

     public function user()
    {
        return $this->belongsTo(User::class);
    }

}
