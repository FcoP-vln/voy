<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyTransactionTypeRequest;
use App\Http\Requests\StoreTransactionTypeRequest;
use App\Http\Requests\UpdateTransactionTypeRequest;
use App\TransactionType;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Binnacle;

class TransactionTypeController extends Controller
{
    public function index()
    {
        abort_if(Gate::denies('transaction_type_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $transactionTypes = TransactionType::all();

        return view('admin.transactionTypes.index', compact('transactionTypes'));
    }

    public function create()
    {
        abort_if(Gate::denies('transaction_type_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.transactionTypes.create');
    }

    public function store(StoreTransactionTypeRequest $request)
    {
        $transactionType = TransactionType::create($request->all());
   
   //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Agregó nueva forma de pago ".strtoupper($transactionType->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.transaction-types.index');
    }

    public function edit(TransactionType $transactionType)
    {
        abort_if(Gate::denies('transaction_type_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.transactionTypes.edit', compact('transactionType'));
    }

    public function update(UpdateTransactionTypeRequest $request, TransactionType $transactionType)
    {
        $transactionType->update($request->all());

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Actualizó forma de pago ".strtoupper($transactionType->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.transaction-types.index');
    

  
    }

    public function show(TransactionType $transactionType)
    {
        abort_if(Gate::denies('transaction_type_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        return view('admin.transactionTypes.show', compact('transactionType'));
    }

    public function destroy(Request $request, TransactionType $transactionType)
    {
        abort_if(Gate::denies('transaction_type_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó tipo de transacción ".strtoupper($transactionType->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        $transactionType->delete();

        return back();
    }

    public function massDestroy(MassDestroyTransactionTypeRequest $request)
    {
        TransactionType::whereIn('id', request('ids'))->delete();

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó varias formas de pago";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
