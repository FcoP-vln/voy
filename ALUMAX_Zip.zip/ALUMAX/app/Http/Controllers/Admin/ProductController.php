<?php

namespace App\Http\Controllers\Admin;


use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyProductRequest;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Cost;
use App\Product;
use App\Accesory;
use App\Accesory_product;
use Gate;
use DB;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use App\Binnacle;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        abort_if(Gate::denies('product_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $products = Product::all();
        $accessories = Accesory::all();
         $accesory_product = Accesory_product::all();  
         
        return view('admin.products.index', compact('products', 'accessories','accesory_product'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        abort_if(Gate::denies('product_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');

       
        return view('admin.products.create');
    }
     public function calcule()
    {
         
        return view('admin.products.calcule');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreProductRequest $request)
    {
       
        //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Agregó nuevo producto ".strtoupper($request->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

       $product = Product::create($request->all());
       $product->costs()->sync($request->input('costs', []));
       $product->accessories()->sync($request->input('accessories', []));
       $product->accessories()->sync($request->input('required'));

        return redirect()->route('admin.products.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        abort_if(Gate::denies('product_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $product->load('accessories');   
                 
        return view('admin.products.show', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product, Accesory_product $accesory_product)
    {
        abort_if(Gate::denies('product_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $costs = Cost::all()->pluck('name','id');        
        $product->load('costs');

        $accessories = Accesory::all()->pluck('name','id','required');
        $product->load('accessories');

        $accesory_product = Accesory_product::all();  
        return view('admin.products.edit', compact('costs', 'product', 'accessories', 'accesory_product'))->with('message', "Producto actualizado");
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product, Accesory $accessories, Accesory_product $accesory_product)
    {
        $product->update($request->all());
         $product->costs()->sync($request->input('costs', []));
         $product->accessories()->sync($request->input('accessories', []));
         $accesory_product = Accesory_product::all();  
        $accessories->update($request->all());
        $accessories->accesory_product()->sync($request->input('required', []));
       
        //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Actualizó información del producto ".strtoupper($product->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all(); 
     
        return redirect()->route('admin.products.index');
    }

  public function updates(Request $request, Product $product)
    {
$product->accesory_product()->sync($request->input('required'));
                
                return redirect()->route('admin.products.edit');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Product $product)
    {
        abort_if(Gate::denies('product_delete'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó producto ".strtoupper($product->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all(); 


        $product->delete();
        
        return back();
    }

      public function massDestroy(MassDestroyProductRequest $request)
    {
        Transaction::whereIn('id', request('ids'))->delete();

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó varios productos.";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return response(null, Response::HTTP_NO_CONTENT);
    }

}
