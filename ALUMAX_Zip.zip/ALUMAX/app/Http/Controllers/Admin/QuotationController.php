<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\MassDestroyQuotationRequest;

use App\Quotation;
use App\ServiciosQuotation;
use App\CaracteristicasQuotation;
use App\CaracteristicaQuotes;
use App\Product;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use App\Binnacle;



class QuotationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      
        return view('admin.quotes.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)

    {
        
    $caracteristica = $request->input('caracteristica');
    if (!$caracteristica == null){
        CaracteristicasQuotation::create($request->all());
               //agrega nueva característica inexistente  
      CaracteristicaQuotes::firstOrCreate(['description'=>$request->input('caracteristica')]); 
        return back();
    }else{
 
    ServiciosQuotation::create($request->all());
    return back();
    }
   }
      
    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $cotizaciones = Quotation::create($request->all());
           
       


        //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Creó cotización #".$cotizaciones->id." para cliente con id#".$cotizaciones->client_id;
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

    
        return view('admin.quotes.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)    
    {

        // $servicios->select('Select * from servicios_quotes');
        return view('admin.quotes.show', compact('id'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        return view('admin.quotes.edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id, Request $request)
    {
      
   
 $caracteristica = $request->input('caracteristica');

    if (!$caracteristica == null){
        CaracteristicasQuotation::find($id)->update($request->all());
        return back();
    }
  if(!Quotation::find($id)){
        ServiciosQuotation::find($id)->update($request->all());


          //agrega nuevo producto inexistente  
      $product = Product::firstOrCreate(['name'=>$request->input('servicio')]); 
      
      if ($product){

        //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Agregó nuevo producto ".strtoupper($request->input('servicio'));
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

      }
       return back();
   }else{
    Quotation::find($id)->update($request->all());


        //actualiza bitácora
     
    return back();
   }  $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Modificó cotización #".$id;
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

    $descuento = $request->input('descuento');
    if (!$descuento == null){
//agrega descuento
        Quotation::find($id)->update($request->input('descuento'));
 
    }
   
    }



    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
      
    if (CaracteristicasQuotation::find($id)){
        CaracteristicasQuotation::find($id)->delete();
        return back();
    }
  if(!Quotation::find($id)){
        ServiciosQuotation::find($id)->delete();
       return back();
   }else{

  
    Quotation::find($id)->delete();

        //actualiza bitácora
       $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó cotización #".$id;
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

    return back();
   }
    }

     public function massDestroy(MassDestroyQuotationRequest $request)
    {
        Quotation::whereIn('id', request('ids'))->delete();

        //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó varias cotizaciones.";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();


        return response(null, Response::HTTP_NO_CONTENT);
    }
}
