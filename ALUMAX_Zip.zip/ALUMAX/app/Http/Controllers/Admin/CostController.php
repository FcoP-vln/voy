<?php

namespace App\Http\Controllers\Admin;
use App\Cost;
use App\Product;
use App\Accesory;
use Gate;
use Illuminate\Http\Request;
use App\Http\Requests\StoreCostRequest;
use App\Http\Requests\MassDestroyCostRequest;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Response;

use App\Binnacle;

class CostController extends Controller
{
    //
    public function index()
    {
        abort_if(Gate::denies('cost_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $costs = Cost::all();
        $accesories = Accesory::all();
    
      
       return view('admin.costs.index', compact('costs', 'accesories'));

    }

    public function create()
    {
        abort_if(Gate::denies('cost_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $products = Product::all()->pluck('name', 'id');

        return view('admin.costs.create', compact('products'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCostRequest $request)
    {
        $cost = Cost::create($request->all());

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Agregó material ".strtoupper($request->input('name'));
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.costs.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Cost $cost)
    {
        abort_if(Gate::denies('cost_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $products = Product::all()->pluck('name', 'id');
        return view('admin.costs.show', compact('cost','products'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Cost $cost)
    {
        abort_if(Gate::denies('cost_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        $products = Product::all()->pluck('name', 'id');
        $cost->load('product');
        return view('admin.costs.edit', compact('cost', 'products'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cost $cost)
    {
        $cost->update($request->all());

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Actualizó información de material ".strtoupper($request->input('name'));
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.costs.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Cost $cost)
    {
         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó material ".strtoupper($cost->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();
    }

     public function massDestroy(MassDestroyCostRequest $request)
    {
        Transaction::whereIn('id', request('ids'))->delete();

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó varios materiales.";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
