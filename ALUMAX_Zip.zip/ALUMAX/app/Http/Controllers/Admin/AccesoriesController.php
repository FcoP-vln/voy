<?php

namespace App\Http\Controllers\Admin;

use App\Accesory;

use App\Cost;
use Gate;
use Illuminate\Http\Request;
use App\Http\Requests\StoreAccesoryRequest;
use App\Http\Requests\MassDestroyAccesoryRequest;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Response;
use App\Binnacle;

class AccesoriesController extends Controller
{
     public function index()
    {
        abort_if(Gate::denies('accesory_access'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        $accesories = Accesory::all();
        $costs = Cost::all();

      
       return view('admin.costs.index', compact('costs','accesories'));

    }

    public function create()
    {
        abort_if(Gate::denies('accesory_create'), Response::HTTP_FORBIDDEN, '403 Forbidden');
        

        return view('admin.accesories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreAccesoryRequest $request)
    {
        $accesory = Accesory::create($request->all());

       //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Creó accesorio ".strtoupper($accesory->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return redirect()->route('admin.costs.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Accesory $accesory)
    {
        abort_if(Gate::denies('accesory_show'), Response::HTTP_FORBIDDEN, '403 Forbidden');

        
        return view('admin.accesories.show', compact('accesory'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Accesory $accesory)
    {
        abort_if(Gate::denies('accesory_edit'), Response::HTTP_FORBIDDEN, '403 Forbidden');
       

        return view('admin.accesories.edit', compact('accesory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Accesory $accesory)
    {



       $accesory->update($request->all());

       //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Actualizó accesorio #".$accesory->id;
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();


       return redirect()->route('admin.costs.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, Accesory $accesory)
    {
               
        //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó accesorio ".strtoupper($accesory->name);
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();
    }

    public function massDestroy(MassDestroyAccesoryRequest $request)
    {
        Transaction::whereIn('id', request('ids'))->delete();

         //actualiza bitácora
        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "Eliminó varios accesorios.";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

        return response(null, Response::HTTP_NO_CONTENT);
    }
}
