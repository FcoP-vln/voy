<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use Illuminate\Support\Facades\Auth;
use App\Binnacle;


class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */
    

    use AuthenticatesUsers;

   

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/admin/clients';


    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
      
    }

    public function authenticated(Request $request){


        $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "INGRESÓ al sistema";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();
    }

     public function logout(Request $request)
  {
    
 $us = new Binnacle();
        
        $us->user_id = auth()->user()->id;
        $us->activity= "SALIDA";
        $us->ip= $request->getClientIp();
        $us->save();
        $us = Binnacle::all();

    Auth::logout();
     return redirect()->route('admin.notes.index');
  }

}