<?php
namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CaracteristicasQuotation extends Model
{
     use HasFactory;
     

      public $table = 'caracteristicas_quotes';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [       
        'quotation_id',
        'caracteristica',
        
    ];
       
}
