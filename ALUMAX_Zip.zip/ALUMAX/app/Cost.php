<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Cost extends Model
{
    use HasFactory;
 	use SoftDeletes;

    public $table = 'costs';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'white',
        'bronze',
        'wood',
        'natural',
        'stock',
        'width_required',
        'high_required',
        'created_at',
        'updated_at',
        'deleted_at',
        'longsize',
        'description',
    ];
     public function cost()
    {
        return $this->hasMany(Cost::class, 'cost_id', 'id');
    }

    public function products()
    {
        return $this->belongsToMany(Product::class);
    }

    public function product()
    {
        return $this->belongsToMany(Product::class);
    }
}
