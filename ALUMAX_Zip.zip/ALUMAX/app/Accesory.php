<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Accesory extends Model
{
    use HasFactory;
 	use SoftDeletes;

    public $table = 'accesories';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'price',
        'stock',
        'description',        
        'created_at',
        'updated_at',
        'deleted_at',
        
    ];
     public function accesory()
    {
        return $this->hasMany(Accesory::class, 'accesory_id', 'id', 'required');
    } 
    
      public function products()
    {
        return $this->belongsToMany(Product::class)->withPivot('required');
    }

    public function product()
    {
        return $this->belongsToMany(Product::class);
    }

   public function accesory_product()
    {

    return $this->belongsToMany(Product::class);
    }

}

