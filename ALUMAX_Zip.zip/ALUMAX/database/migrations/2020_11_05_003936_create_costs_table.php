<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCostsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('costs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->decimal('white', 15, 2)->nullable();
            $table->decimal('bronze', 15, 2)->nullable();
            $table->decimal('wood', 15, 2)->nullable();
            $table->decimal('natural', 15, 2)->nullable();
            $table->decimal('width_required', 15, 2)->nullable();
            $table->decimal('high_required', 15, 2)->nullable();
            $table->decimal('stock', 15, 2)->nullable();
            $table->integer('long')->nullable();
            $table->string('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('costs');
    }
}
