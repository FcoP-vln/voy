
<?php $__env->startSection('content'); ?>

<?php
use App\Quotation;
use App\Client;
use App\ClientStatus;
use App\Invoice;
$cotizaciones = Quotation::all()->sortByDesc('id');
$clientes = Client::all();
$statuses = ClientStatus::all();
$facturas = Invoice::all()->sortByDesc('id');

?>

<div class="row">
    <div class="col-sm">
        <h1><?php echo e(trans('cruds.bills.title')); ?></h1>
        
    </div>
</div>
<!-- Bills header-->
<div class="row">
    <div class="col-sm">
        <p>
            <a href="#new" class="btn btn-success" data-toggle="modal">
                <i class="fa fa-plus"></i> <?php echo e(trans('cruds.bills.fields.new')); ?>

            </a>
        </p>   
    </div>

</div>

<!-- Bills body -->
<div class="card">
    <div class="card-header">
       <?php echo e(trans('cruds.bills.title')); ?> - <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Quotation">
                <thead>
                <tr>
                    <th width="10"></th>
                    <th><?php echo e(trans('cruds.bills.title_singular')); ?> #</th>
                    <th><?php echo e(trans('cruds.quotes.title_singular')); ?> #</th>
                    <th><?php echo e(trans('cruds.bills.fields.client')); ?></th>
                    <th><?php echo e(trans('cruds.bills.fields.date')); ?></th>
                    <th><?php echo e(trans('cruds.bills.fields.state')); ?></th>
                    <th text-align="center"><?php echo e(trans('global.datatables.print')); ?></th>
                    <th align="center"><?php echo e(trans('global.edit')); ?>/RTN</th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr data-entry-id="<?php echo e($factura->id); ?>">
                        <td>
                           
                        </td>
                        <td>000-001-01-00000<?php echo e($factura->id ?? ''); ?></td>
                        <td>#<?php echo e($factura->quotation_id ?? ''); ?>   
                        </td> 
                                          
                        <td><?php echo e($factura->client ?? ''); ?>

                        </td>
                        <td><?php echo e(date('d-m-Y', strtotime($factura->invoice_date)) ?? ''); ?></td>
                        <td><?php echo htmlentities($factura->estado) ?? '' ?></td>
                        <?php $idC= $factura->quotation_id ?>
                        <td align="center">
                            <a class="btn btn-primary"
                                href='/admin/imprimirFac/?id=<?php echo e($factura->id); ?>'onclick="window.open(this.href, 'Cotización#<?php echo e($factura->id); ?>', 'width=700, height=700,');return false;"><i class="fa fa-file-pdf" aria-hidden="true"></i>
                            </a>
                        </td>
                        <td align="center">
                            <a class="btn btn-warning"
                               href="#edit<?php echo e($factura->id); ?>" data-toggle="modal">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td> 
                    </tr>
                                     <!-- MODAL EDITAR-->
                            <div class="modal fade" id="edit<?php echo e($factura->id); ?>" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1><?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.bills.title_singular')); ?> #000-001-01-00000<?php echo e($factura->id); ?></h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="<?php echo e(route('admin.bills.update', [$factura->id])); ?>" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <?php echo e(csrf_field()); ?>

                                                 <?php echo e(method_field('PUT')); ?>

                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
                                               </div>
                                            <div class="form-group">

                                                <label for="client"><?php echo e(trans('cruds.bills.fields.client')); ?>:</label>
                                                
                                            <input value="<?php echo e(old('client', isset($factura) ? $factura->client : '')); ?>" name="client" autocomplete="off" required type="text"
                                                    class="form-control" id="client" >
                                            </div>
                                              <div class="form-group">

                                                <label for="rtn">RTN:</label>
                                                
                                            <input type="number" min="1" step="1" value="<?php echo e(old('rtn', isset($factura) ? $factura->rtn : '')); ?>" name="rtn" placeholder="Ingrese registro sin guión ni espacios" autocomplete="off" class="form-control" id="rtn" >
                                            </div>
                                            <div class="form-group">

                                              <label for="quotation_id"><?php echo e(trans('cruds.quotes.title_singular')); ?>:</label>
                                              <select required class="form-control" name="quotation_id">
                                                <?php foreach ($cotizaciones as $cotizacion) { ?>
                                                  <option value="<?php echo $cotizacion->id ?>" <?php echo e((isset($factura) && $factura->quotation_id ? $factura->quotation_id : old ('quotation_id')) == $cotizacion->id ? 'selected' : ''); ?>><span>#</span><?php echo e($cotizacion->id); ?></option>
                                                <?php } ?>
                                              </select>

                                            </div>
                                            <div class="form-group">
                                                <label for="estado"><?php echo e(trans('cruds.bills.fields.state')); ?>:</label>
                                                
                                                <select autofocus required class="form-control" id="estado" name="estado" required>
                                                    
                                                        <option  value="<?php echo $factura->estado ?>" <?php echo e((isset($factura) && $factura->estado ? $factura->estado : old('estado')) == $factura->estado  ? 'selected' : ''); ?>><?php echo e($factura->estado); ?>

                                                            </option>
                                                            <option>Pendiente</option>
                                                            <option>Cancelada</option>
                                                            <option>NULA</option>
                                                   
                                                </select>
                                            </div>
                                                <div class="form-group">
                                                    <label for="invoice_date"><?php echo e(trans('cruds.bills.fields.date')); ?>:</label>
                                                    <input value="<?php echo e(old('invoice_date', isset($factura) ? $factura->invoice_date : '')); ?>" name="invoice_date" autocomplete="off" required type="date"
                                                    class="form-control" id="fecha" >
                                                </div>  

                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="<?php echo e(trans('cruds.receipts.fields.save_changes')); ?>">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <!-- fin modal editar -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Bills body end -->

<!-- CAI Button -->

<div class="row">
  <div class="col-sm">
<hr><a class="btn btn-dark"
     href="#editCAI" data-toggle="modal">
    <i class="fa fa-edit"><strong>CAI</strong></i>
      </a>
</div>
</div>


<?php 
use App\Cai;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Http\Request;
$rangos = Cai::all();

$cai = new CAI();
$rang = $_POST['id']??'';


if(!$rang==null){
$cai=CAI::where('id', '=', $rang)->first();
  
   // Setear un nuevo rango
   $cai->rango_desde = $_POST['rango_desde'];
   $cai->rango_hasta = $_POST['rango_hasta'];
   $cai->cai = $_POST['cai'];
   $cai->fecha_limite = $_POST['fecha_limite'];
 
   // Guardar en base de datos
   $cai->save();
   $rangos = Cai::all();
}


 ?>

  <div class="row">
    <!-- MODAL CAI rango fACTURAS-->
  <div class="modal fade" id="editCAI" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                        <h3>Rango Autorizado</h3>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="form" action="/admin/bills" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('GET')); ?>

               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
            </div>
            <?php $__currentLoopData = $rangos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$rango): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
              <input type="hidden" name="id" value="<?php echo e($rango->id); ?>">
              <label>Desde:</label>
             <input class="form-control" type="text"  value="<?php echo e($rango->rango_desde); ?>" name="rango_desde">
                       
            </div>
            <div class="form-group">
  
              <label>Hasta:  </label>
              <input class="form-control" type="text"  value="<?php echo e($rango->rango_hasta); ?>" name="rango_hasta">          
            </div>
            <div class="form-group">
              <label for="cai">CAI:</label>
              <input class="form-control" type="text" name="cai" value="<?php echo e($rango->cai); ?>">
             
             </div>
         
             <div class="form-group">
                <label for="fecha_limite">Fecha límite:</label>
                <input type="date" name="fecha_limite" value="<?php echo e($rango->fecha_limite); ?>">
            </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Actualizar">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal CAI-->
</div>


<div class="row">
    <!-- MODAL CREAR-->
  <div class="modal fade" id="new" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
           
                    	<?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$facturita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php 
                        $new = $facturita->id;
                              $nueva= $new + 1; 
                              break;
                         ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <h3><?php echo e(trans('cruds.bills.fields.new')); ?> #000-001-01-00000<?php echo e($nueva ?? ''); ?></h3>
                       
                    </div>
                </div> 
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="formAP" action="<?php echo e(route('admin.bills.store')); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('POST')); ?>

               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
            </div>
            <div class="form-group">         
            </div>
            <div class="form-group">

                <label for="quotation_id"><?php echo e(trans('cruds.quotes.title_singular')); ?>:</label>
                <select required class="form-control" name="quotation_id" id="quotation_id" >
                    <?php foreach ($cotizaciones as $cotizacion) { ?>
                        <option value="<?php echo $cotizacion->id ?>"><span>#</span><?php echo e($cotizacion->id); ?></option>
                    <?php } ?>
                </select>
              
             </div>
              
             <div class="form-group">
                <label for="quotation_date"><?php echo e(trans('cruds.bills.fields.date')); ?>:</label>
                <input value="<?php echo date("Y-m-d") ?>" name="invoice_date" autocomplete="off" required type="date"
                       class="form-control" id="fecha">
            </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Crear">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.quotes.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  $('.datatable-Quotation:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/bills/index.blade.php ENDPATH**/ ?>