<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\master-php\ALUMAX\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>