
<h1>HOLAAA</h1>
<?php 


echo "HOLAAAA"; 

?>

@<?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/products/calcule.blade.php ENDPATH**/ ?>