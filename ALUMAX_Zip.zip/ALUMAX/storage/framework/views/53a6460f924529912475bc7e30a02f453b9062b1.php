
<?php $__env->startSection('content'); ?>

<?php
use App\Quotation;
use App\Client;
use App\ClientStatus;
use App\Receipt;
$cotizaciones = Quotation::all()->sortBy('id');
$clientes = Client::all()->sortByDesc('id');
$statuses = ClientStatus::all();
$recibos = Receipt::all()->sortBy('id');
?>

<div class="row">
    <div class="col-sm">
        <h1><?php echo e(trans('cruds.receipts.title')); ?></h1>
        
    </div>
</div>

<div class="row">
    <div class="col-sm">
        <p>
            <a href="#new" class="btn btn-success" data-toggle="modal">
                <i class="fa fa-plus"></i> <?php echo e(trans('cruds.receipts.fields.new')); ?>

            </a>
        </p>   
    </div>
   
    
    
</div>

<div class="card">
    <div class="card-header">
       Recibos - <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Receipts">
                <thead>
                <tr>
                    <th width="10"></th>
                    <th><?php echo e(trans('cruds.receipts.title_singular')); ?> #</th>
                    <th><?php echo e(trans('cruds.receipts.fields.client')); ?></th>
                    <th><?php echo e(trans('cruds.receipts.fields.initial')); ?></th>
                    <th><?php echo e(trans('cruds.receipts.fields.payment')); ?></th>
                    <th><?php echo e(trans('cruds.receipts.fields.balance')); ?></th>
                    <th><?php echo e(trans('cruds.receipts.fields.date')); ?></th>
                    <th class="text-center"><?php echo e(trans('global.datatables.print')); ?></th>
                    <th class="text-center"><?php echo e(trans('global.edit')); ?></th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotes_delete')): ?>
                    <th class="text-center"><?php echo e(trans('global.delete')); ?></th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody> <?php 
                $saldo= 0.00;
                $si = 0.00;
                $abono= 0.00;
                 ?>
                <?php $__currentLoopData = $recibos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$recibo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($recibo->id); ?>">
                        <td>
                            
                        </td>
                        <td><?php echo e($recibo->id ?? ''); ?>   
                        </td>
                        <td><?php echo e($recibo->nombre ?? ''); ?>   
                        </td>
                        <td>L. <?php echo e(number_format($recibo->saldo_inicial,2)); ?></td>
                        <td>L. <?php echo e(number_format($recibo->abono, 2)); ?></td>
                        <td align="center">
                            
                        	<!-- Cálculo de SALDO -->
                            <?php 
                            $si =  $recibo->saldo_inicial;
                            $abono = $recibo->abono;
                            $saldo =$si - $abono;

                            ?>
                            <b>L. <?php echo e(number_format($saldo, 2)); ?></b>

                        </td>
                        <td><?php echo e(date('d-m-Y', strtotime($recibo->fecha))); ?></td>
                        <td align="center">
                            <a class="btn btn-primary"
                                href='/admin/imprimirR/?id=<?php echo $recibo->id ?>' target="_blank">
                                <i class="fa fa-print"></i>
                            </a>
                        </td>
                        <td align="center">
                            <a class="btn btn-warning"
                               href="#edit<?php echo e($recibo->id); ?>" data-toggle="modal">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotes_delete')): ?>
                        <td align="center">
                            <form action="<?php echo e(route('admin.receipts.destroy', $recibo->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn btn-danger"> <i class="fa fa-trash"></i> </button>
                            </form>
                        </td>    
                             <?php endif; ?>
                    </tr>
                                     <!-- MODAL EDITAR-->
                            <div class="modal fade" id="edit<?php echo e($recibo->id); ?>" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1><?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.receipts.title_singular')); ?> #<?php echo e($recibo->id); ?></h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="<?php echo e(route('admin.receipts.update', [$recibo->id])); ?>" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <?php echo e(csrf_field()); ?>

                                                 <?php echo e(method_field('PUT')); ?>

                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
                                               </div>
                                            <div class="form-group">
                                              <label for="nombre"><?php echo e(trans('cruds.receipts.fields.client')); ?>:</label> 
                                              <input type="text" name="nombre" class="form-control" value= "<?php echo e(old('nombre', isset($recibo) ? $recibo->nombre : '')); ?>">
  											</div>

                                            <div class="form-group">
                                                <label for="saldo_inicial"><?php echo e(trans('cruds.receipts.fields.initial')); ?>:</label>
                                                
                                                <input type="text" name="saldo_inicial" class="form-control" value="<?php echo e(old('saldo_inicial', isset($recibo) ? $recibo->saldo_inicial : '')); ?>">
                                            </div>
                                              <div class="form-group">
                                                <label for="abono"><?php echo e(trans('cruds.receipts.fields.payment')); ?>:</label>
                                                <input type="text" name="abono" class="form-control" value="<?php echo e(old('abono', isset($recibo) ? $recibo->abono: '')); ?>">
                                            </div>

                                            <div class="form-group">
                                            	<label for="descripcion"><?php echo e(trans('cruds.receipts.fields.concept')); ?>:</label>
                                            	<textarea name="descripcion" class ="form-control" required><?php echo e(old('descripcion', isset($recibo) ? $recibo->descripcion : '')); ?></textarea>
                                            </div>

                                                <div class="form-group">
                                                    <label for="fecha"><?php echo e(trans('cruds.receipts.fields.date')); ?>:</label>
                                                    <input value="<?php echo e(old('fecha', isset($recibo) ? $recibo->fecha : '')); ?>" name="fecha" autocomplete="off" required type="date"
                                                    class="form-control" id="fecha" >
                                                </div>  

                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="<?php echo e(trans('cruds.receipts.fields.save_changes')); ?>">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <!-- fin modal editar -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row">
    <!-- MODAL CREAR-->
  <div class="modal fade" id="new" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                    	<?php $__currentLoopData = $recibos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recibo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $new = $recibo->id;
                              $nueva= $new + 1; 
                         ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <h1><?php echo e(trans('cruds.receipts.fields.new')); ?> #<?php echo e($nueva ?? ''); ?></h1>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="formAP" action="#" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('POST')); ?>

               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
            </div>        
               <div class="form-group">
                <label for="nombre"><?php echo e(trans('cruds.receipts.fields.name')); ?>:</label>
                <input type="text" name="nombre" class ="form-control" placeholder="Ingrese nombre completo" required>
              </div>

              <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.receipts.fields.initial')); ?>:</label>
                <input type="number" step="0.1" min="1" name="saldo_inicial" class ="form-control" placeholder="Lps 0.00" required>
              </div>

              <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.receipts.fields.payment')); ?>:</label>
                <input type="number" step="0.1" min="1" name="abono" class ="form-control" placeholder="Lps 0.00" required>
              </div>

              <div class="form-group">
               <label for="descripcion"><?php echo e(trans('cruds.receipts.fields.concept')); ?>:</label>
               <textarea name="descripcion" class ="form-control" required></textarea>
              </div>

              <div class="form-group">
                <label for="quotation_date"><?php echo e(trans('cruds.receipts.fields.date')); ?>:</label>
                <input value="<?php echo date("Y-m-d") ?>" name="fecha" autocomplete="off" required type="date" class="form-control" id="fecha">
              </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="<?php echo e(trans('cruds.receipts.fields.create')); ?>">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.quotes.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 25,
  });
  $('.datatable-Receipts:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/receipts/index.blade.php ENDPATH**/ ?>