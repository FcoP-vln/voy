
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.accesory.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.accesories.update", [$accesory->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.accesory.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($accesory) ? $accesory->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.accesory.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                <label for="price"><?php echo e(trans('cruds.accesory.fields.price')); ?>*</label>
                <input type="number" min="0" id="price" name="price" class="form-control" value="<?php echo e(old('name', isset($accesory) ? $accesory->price : '')); ?>" step='0.01'  required>
                <?php if($errors->has('price')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('price')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.accesory.fields.price_helper')); ?>

                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('stock') ? 'has-error' : ''); ?>">
                <label for="stock"><?php echo e(trans('cruds.accesory.fields.stock')); ?> inicial*</label>
                <input type="number" min="0" id="stock" name="stock" class="form-control" value="<?php echo e(old('stock', isset($accesory) ? $accesory->stock : '')); ?>"  required>
                <?php if($errors->has('stock')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('stock')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.accesory.fields.stock_helper')); ?>

                </p>
            </div>            
            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.accesory.fields.description')); ?>*</label>
                <textarea id="description" name="description" class="form-control " required><?php echo e(old('description', isset($accesory) ? $accesory->description : '')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('description')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.accesory.fields.description_helper')); ?>

                </p>
            </div>
            <div>


            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
                 <a  class="btn btn-default" href="<?php echo e(url()->previous()); ?>">
                <?php echo e(trans('global.back_to_list')); ?>

            </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/accesories/edit.blade.php ENDPATH**/ ?>