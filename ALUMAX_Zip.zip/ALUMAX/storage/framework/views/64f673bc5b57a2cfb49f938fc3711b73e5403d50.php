
<?php $__env->startSection('content'); ?>

<h1>EDITAR 2</h1>


<?php $__env->stopSection(); ?>


























<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/accesories/edit2.blade.php ENDPATH**/ ?>