
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.transaction.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.transactions.update", [$transaction->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('project_id') ? 'has-error' : ''); ?>">
                <label for="project"><?php echo e(trans('cruds.transaction.fields.project')); ?>*</label>
                <select name="project_id" id="project" class="form-control select2" required>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($transaction) && $transaction->project ? $transaction->project->id : old('project_id')) == $id ? 'selected' : ''); ?>><?php echo e($project); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('project_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('project_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('transaction_type_id') ? 'has-error' : ''); ?>">
                <label for="transaction_type"><?php echo e(trans('cruds.transaction.fields.transaction_type')); ?>*</label>
                <select name="transaction_type_id" id="transaction_type" class="form-control select2" required>
                    <?php $__currentLoopData = $transaction_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $transaction_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($transaction) && $transaction->transaction_type ? $transaction->transaction_type->id : old('transaction_type_id')) == $id ? 'selected' : ''); ?>><?php echo e($transaction_type); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('transaction_type_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('transaction_type_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('income_source_id') ? 'has-error' : ''); ?>">
                <label for="income_source">Requerido: *</label>
                <select name="income_source_id" id="income_source" class="form-control select2" required>
                    <?php $__currentLoopData = $income_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $income_source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($transaction) && $transaction->income_source ? $transaction->income_source->id : old('income_source_id')) == $id ? 'selected' : ''); ?>><?php echo e($income_source); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('income_source_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('income_source_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('amount') ? 'has-error' : ''); ?>">
                <label for="amount"><?php echo e(trans('cruds.transaction.fields.amount')); ?>*</label>
                <input type="number" id="amount" name="amount" class="form-control" value="<?php echo e(old('amount', isset($transaction) ? $transaction->amount : '')); ?>" step="0.01" required>
                <?php if($errors->has('amount')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('amount')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.transaction.fields.amount_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('currency_id') ? 'has-error' : ''); ?>">
                <label for="currency"><?php echo e(trans('cruds.transaction.fields.currency')); ?>*</label>
                <select name="currency_id" id="currency" class="form-control select2" required>
                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($transaction) && $transaction->currency ? $transaction->currency->id : old('currency_id')) == $id ? 'selected' : ''); ?>><?php echo e($currency); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('currency_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('currency_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('transaction_date') ? 'has-error' : ''); ?>">
                <label for="transaction_date"><?php echo e(trans('cruds.transaction.fields.transaction_date')); ?>*</label>
                <input type="text" id="transaction_date" name="transaction_date" class="form-control date" value="<?php echo e(old('transaction_date', isset($transaction) ? $transaction->transaction_date : '')); ?>" required>
                <?php if($errors->has('transaction_date')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('transaction_date')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.transaction.fields.transaction_date_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.transaction.fields.name')); ?></label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($transaction) ? $transaction->name : '')); ?>">
                <?php if($errors->has('name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.transaction.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.transaction.fields.description')); ?></label>
                <textarea id="description" name="description" class="form-control "><?php echo e(old('description', isset($transaction) ? $transaction->description : '')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('description')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.transaction.fields.description_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/transactions/edit.blade.php ENDPATH**/ ?>