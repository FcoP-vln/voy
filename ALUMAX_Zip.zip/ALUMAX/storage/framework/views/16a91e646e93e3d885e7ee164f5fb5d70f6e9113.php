
<?php $__env->startSection('content'); ?>
<h1>INVENTARIO DE MATERIALES SOBRANTES</h1>
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sobrante_create')): ?>
  <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="#crear" data-toggle="modal">
                <?php echo e(trans('global.add')); ?> 
            </a>
        </div>
    </div>
<?php endif; ?>
<div class="card">
    <div class="card-header">
        Materiales sobrantes - <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-Sobrantes">
                <thead>
                    <tr>
                        <th width="10">

                        </th>
                        <th>
                            Cotización #
                        </th>
                        <th>
                            Material
                        </th>
                        <th>
                        	Cantidad (metros)
                        </th>
                        <th>
                        	Color
                        </th>
                        <th>
                        	Guardado en fecha
                        </th>

                        <th>
                            &nbsp;
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sobrantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sobrante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($sobrante->id); ?>">
                            <td>

                            </td>
                            <td>
                                <?php echo e($sobrante->quotation_id ?? ''); ?>

                            </td>
                            <td>
                                <?php echo e($sobrante->material ?? ''); ?>

                            </td>
                            <td>
                            	<?php echo e($sobrante->cantidad ?? ''); ?>

                            </td>
                            <td>
                            	<?php echo e($sobrante->color ?? ''); ?>

                            </td>
                            <td>
                            	<?php echo e($sobrante->created_at ?? ''); ?>

                            </td>
                            <td>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sobrante_edit')): ?>
                                    <a class="btn btn-xs btn-info" href="#edit<?php echo e($sobrante->id); ?>" data-toggle="modal">
                                        <?php echo e(trans('global.edit')); ?>

                                    </a>

                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sobrante_delete')): ?>
                                    <form action="<?php echo e(route('admin.sobrantes.destroy', $sobrante->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="submit" class="btn btn-xs btn-danger" value="Utilizar">
                                    </form>

                                <?php endif; ?>

                            </td>

                        </tr>
                        <!-- MODAL EDITAR-->
  <div class="modal fade" id="edit<?php echo e($sobrante->id); ?>" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">

                     
                        <h3>Editar información</h3>
                       
                    </div>
                </div> 
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="form" action="<?php echo e(route('admin.sobrantes.update', $sobrante->id)); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('PUT')); ?>

               <div class="form-group">
            
            </div>
            <div class="form-group">  
                <label for="material">Material: </label>
            <input type="text" class="form-control" name="material" value="<?php echo e(old('material', isset($sobrante) ? $sobrante->material : '')); ?>"> 
            <?php if($errors->has('material')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('material')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.client.fields.first_name_helper')); ?>

                </p>
          
            </div>
            <div class="form-group">
                <label for="cantidad">Cantidad (metros): </label>
                <input type="number" class="form-control" min="1" step="0.1" name="cantidad" value="<?php echo e(old('cantidad', isset($sobrante) ? $sobrante->cantidad : '')); ?>">
                <?php if($errors->has('cantidad')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('cantidad')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.client.fields.first_name_helper')); ?>

                </p>
             </div>
              <div class="form-group">  
                <label for="color">Color: </label>
            <input type="text" class="form-control" name="color" value="<?php echo e(old('color', isset($sobrante) ? $sobrante->color : '')); ?>">    
            <?php if($errors->has('color')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('color')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.client.fields.first_name_helper')); ?>

                </p>
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Crear">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="row">
    <!-- MODAL CREAR-->
  <div class="modal fade" id="crear" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">

                     
                        <h3>Nueva material sobrante</h3>
                       
                    </div>
                </div> 
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="form" action="<?php echo e(route('admin.sobrantes.store')); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('POST')); ?>

               <div class="form-group">
            
            </div>
            <div class="form-group">  
                <label for="material">Material: </label>
            <input type="text" class="form-control" name="material">       
            </div>
            <div class="form-group">

                <label for="cantidad">Cantidad (metros): </label>
                <input type="number" class="form-control"min="1" step="0.1" name="cantidad">
             </div>
              <div class="form-group">  
                <label for="color">Color: </label>
            <input type="text" class="form-control" name="color">    
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Crear">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/sobrantes/index.blade.php ENDPATH**/ ?>