
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
       <label> <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.cost.fields.name')); ?></label>
    </div>

    <div class="card-body">
        <div class="mb-2">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.cost.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($cost->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.cost.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($cost->name); ?>

                        </td>
                    </tr>
                     <tr>
                        <th>
                            <?php echo e(trans('cruds.cost.fields.description')); ?>

                        </th>
                        <td>
                            <?php echo e($cost->description); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            Para producto:
                        </th>
                        <td>
                           
                 <ul>
                    <?php $__currentLoopData = $cost->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name=> $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($products->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                        </td>
                        
                    </tr>
                    <tr>
                        <th>
                            Requerido en producto:
                        </th>
                        <td>
                            <?php echo e($cost->width_required); ?> de ancho <b>+</b> <?php echo e($cost->high_required); ?> de alto
                        </td>

                    </tr>
                         <tr>
                        <th>
                            Largo:
                        </th>
                        <td>
                            <?php echo e($cost->longsize); ?> cm
                        </td>

                    </tr>
                </tbody>
            </table>
            <label>Precios: </label>
            

                  
            <br/>
            <table class="table table-bordered table-striped">
                	<tr>
                        <th>
                            <?php echo e(trans('cruds.cost.fields.white')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.cost.fields.bronze')); ?>

                        </th>
                        <th>
                            <?php echo e(trans('cruds.cost.fields.wood')); ?>

                        </th>  
                        <th>
                            <?php echo e(trans('cruds.cost.fields.natural')); ?>

                        </th>                       
                    </tr>
                    <tr>
                    	<td>
                           Lps. <?php echo e($cost->white); ?>

                        </td>
                    	<td>
                    		Lps. <?php echo e($cost->bronze); ?>

                    	</td>
                    	<td>
                    		Lps. <?php echo e($cost->wood); ?>

                    	</td>
                    	<td>
                    		Lps. <?php echo e($cost->natural); ?>

                    	</td>
                    </tr>
               </table>
            <a style="margin-top:20px;" class="btn btn-default" href="<?php echo e(url()->previous()); ?>">
                <?php echo e(trans('global.back_to_list')); ?>

            </a>
        </div>

        <nav class="mb-3">
            <div class="nav nav-tabs">

            </div>
        </nav>
        <div class="tab-content">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/costs/show.blade.php ENDPATH**/ ?>