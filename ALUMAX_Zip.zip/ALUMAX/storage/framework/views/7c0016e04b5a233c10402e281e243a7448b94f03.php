

<?php $__env->startSection('content'); ?>

<div class="content">
	<div class="row">
    <div class="col-lg-4">
  </div>
		<div class="col-lg-4">
			<h2 align="center"><b>Costos de materia prima</b></h2>
            <?php 
            use App\Product;

            $name= DB::select('SELECT * from products');
            $pro = $name;
            ?>
            <br>
            <div class="card">
               <div class="card-header">
               </div>
               <div class="card-body">  
                <div class="table-responsive">   
                   <form method="POST" action="<?php echo e(route('admin.home')); ?>" id="form">
                     <?php echo csrf_field(); ?>

                     <?php echo e(csrf_field()); ?>

                     <?php echo e(method_field('GET')); ?>


                     <div>  
                     <label>Seleccione producto:</label>              
                        <select name="id_pro" id="id_pro" class="form-control" value="Seleccione" required>

                         <?php $__currentLoopData = $pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                         <option><?php echo e($dato->id); ?>. <?php echo e($dato->name); ?></option>

                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>                
                 </div>


                 <br>


                 <div class="input-group">
                  <input type="number" class="form-control" name="ancho" id="ancho" placeholder="Ancho(cm)" step="0.1" min="40" required><span class="input-group-addon"><strong> X </strong></span>
                  <input type="number" class="form-control" name="alto" id="alto" placeholder="Alto(cm)" step="0.1" min="30" required><br><br>
              </div>
              <div>
                  <select name="color" class="form-control" value="NATURAL">
                     <option>BLANCO</option>
                     <option>BRONCE</option>
                     <option>MADERA</option>
                     <option>NATURAL</option>
                 </select>
             </div>
             <div>
                <br>
                <button type="submit" id="enviar" onclick="show('resumen');" class="btn btn-success">ENVIAR</button>
            </div>
        </form>
    </div>
</div>
</div>

</div>
</div>
<div class="row">
  <div class="col-lg-2">
  </div>
    <div class="col-lg-8">

        <div class="card" style="display: show;">
            <?php 
            use App\User;

            use App\Cost;
            use App\Accesory_product;
            use Illuminate\Http\Request;
            use Symfony\Component\HttpFoundation\Response;

            $id = request('id_pro');
            $color= request('color');
            $ancho = request('ancho');
            $alto = request('alto');

            echo "<hr>";

            echo "<div class='card-header'>"; 
            $products=Product::find($id);
            $require=Accesory_product::find($id);
            
            echo "<h2>".strtoupper($products->name ?? '')." ".$ancho."x".$alto." - color ".$color."</h2>";
            echo "<h3>".($products->description ?? '')."</h3>";
            echo '<br>';
            echo "</div>";
            echo "<div class='card-body'>"; 
            echo '<b>MATERIALES:</b>';

            $TOTAL = 0.00;
            echo '<table class="table table-bordered table-striped table-hover datatable datatable-Product">';
//Cálculo de materiales

            if(isset($products->costs)){
                foreach($products->costs as $material) {
                    echo '<tr>';

                    echo '<td >'.$material->name.'</td>';
                    if ($color=='BLANCO'){
                       $cm= $material->white/$material->longsize;
                       $required=$material->width_required*$ancho + $material->high_required*$alto;
                       $c1= round($cm*$required, 2);
                       echo '<td>L. '.$c1.'</td>';      
                   }elseif($color=='BRONCE'){
                       $cm= $material->bronze/$material->longsize;
                       $required=$material->width_required*$ancho + $material->high_required*$alto;
                       $c1= round($cm*$required, 2);
                       echo '<td>L.'.$c1.'</td>'; 	
                   }elseif($color=='MADERA'){
                      $cm= $material->wood/$material->longsize;
                      $required=$material->width_required*$ancho + $material->high_required*$alto;
                      $c1= round($cm*$required, 2);
                      echo '<td>L.'.$c1.'</td>'; 

                  }elseif ($color=='NATURAL') {
                   $cm= $material->natural/$material->longsize;
                   $required=$material->width_required*$ancho + $material->high_required*$alto;
                   $c1= round($cm*$required, 2);
                   echo '<td>L.'.$c1.'</td>';    	
               }

               $TOTAL += $c1??'0.00';

               echo '</tr>';
           };
       }



       echo "<tr><td  align='right'><h4><b>TOTAL materiales: Lps. </b></h4></td>"."<td><h3><b>".$TOTAL."</b></h4></td>"."<br><tr>";
       echo '</table>';
       echo '<hr>';

//Cálculo de Accesorios
       echo '<b>ACCESORIOS:</b>';
       $TOTAL2 = 0;
       echo '<table border="2" class="table table-bordered table-striped table-hover datatable datatable-Product">';
       if(isset($products->accessories)){
        foreach($products->accessories as $precio){

            $accesory_id = $precio->id;

            $required = DB::select('select required from accesory_product where product_id= ? and accesory_id=?', [$id, $accesory_id] );
            $ya = $required;
foreach($required as $requ){
            echo '<tr>';
            echo '<td>'.$precio->name.' ('.$requ->required.')</td>';
            $requerido = $requ->required;

}       $c2=$precio->price*$requerido;
echo '<td>L. '.$c2.'</td>';

        //     if ($precio->name=='Tornillo avellanado 100mmx3plg'){
        //       $c2=$precio->price*2;
        //       echo '<td>L. '.$c2.'</td>';
        //   }elseif ($precio->name=='Tornillo 8x1 de malla'){
        //       $c2=$precio->price*11;
        //       echo '<td>L. '.$c2.'</td>';
        //   }elseif ($precio->name=='Tornillo 10x 1½ para instalar'){
        //       $c2=$precio->price*5;
        //       echo '<td>L. '.$c2.'</td>';
        //   }elseif($precio->name=='Taco Fisher S-6'){
        //       $c2=$precio->price*5;
        //       echo '<td>L. '.$c2.'</td>';
        //   }elseif ($precio->name=='Tornillo 10x3/8 para sujetador'){
        //       $c2=$precio->price*2;
        //       echo '<td>L. '.$c2.'</td>';
        //   }elseif ($precio->name=='Rodos'){
        //       $c2=$precio->price*2;
        //       echo '<td>L. '.$c2.'////'.$requerido.'</td>';
        //   }elseif ($precio->name=='Escuadra para malla natural'){
        //       $c2=$precio->price*4;
        //       echo '<td>L. '.$c2.'</td>';
        //   }else{
        //     $c2=$precio->price;
            
        //     echo '<td>L. '.$c2.'</td>';
        // }

        $TOTAL2 += $c2;

        echo '</tr>';


    }; 
}



echo "<tr><td align='right'><h4><b>TOTAL accesorios: Lps. </b></h4><td><h3><b>".$TOTAL2."</b></h3></td></tr><br>";
echo '</table>';
echo "</div>";
echo '<hr>';
$TOTALES = 0.00;
$TOTALES = $TOTAL+$TOTAL2;
?>
<div class="card-footer">
    <div class="text-center">
        <h1>Costos totales del producto: <strong>Lps. <?php echo e($TOTALES); ?></strong></h1>
    </div>

</div>


</div>  <!-- card-body -->

</div>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.2.1.js"></script>



##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/home.blade.php ENDPATH**/ ?>