
<?php $__env->startSection('content'); ?>
<?php use App\Accesory_product;?>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.product.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.products.update", [$product->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.product.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($product) ? $product->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.product.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.product.fields.description')); ?>*</label>
                <textarea id="description" name="description" class="form-control " required><?php echo e(old('description', isset($product) ? $product->description : '')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('description')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.product.fields.description_helper')); ?>

                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('costs') ? 'has-error' : ''); ?>">
                <label for="costs"><?php echo e(trans('cruds.product.fields.material')); ?>*
                    <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                <select name="costs[]" id="costs" class="form-control select2" multiple="multiple" required>
                    <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $costs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('costs', [])) || isset($product) && $product->costs->contains($id)) ? 'selected' : ''); ?>><?php echo e($costs); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('costs')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('costs')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.cost_helper')); ?>

                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('accessories') ? 'has-error' : ''); ?>">
                <label for="accessories"><?php echo e(trans('cruds.accesory.title')); ?>*
                    <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                <select name="accessories[]" id="accessories" class="form-control select2" multiple="multiple" required>
                     <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $accessories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('accessories', [])) || isset($product) && $product->accessories->contains($id)) ? 'selected' : ''); ?>><?php echo e($accessories); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>        
                <?php if($errors->has('accessories')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('accessories')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.cost_helper')); ?>

                </p>
            </div>
            <div>
              <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
          </div>
          </form>

</div>
</div>

<hr>
<!-- CANTIDADES -->
<div class="card">
    <div class="card-body">
            <label for="required">Cantidades*</label><br>
               <?php $__currentLoopData = $product->accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $accessories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>              
                <?php echo e($accessories->name); ?>:
        <input type="text"  name="required" class="form-control" value="<?php echo e(old('required', isset($accessories) ? $accessories->pivot->required: '')); ?>" readonly>

        <a href="#" class="btn btn-xs btn-primary pull-right" data-toggle="modal" data-target="#create<?php echo e($accessories->id); ?>">Editar cantidad</a>
                <br>
              
      
       
      <!--MODAL  -->
<div class="modal fade" id="create<?php echo e($accessories->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Cantidad requerida</h3>
                <button type="button" class="close" data-dismiss="modal">
                    <span>×</span>
                </button>
               
            </div>
           <div class="card">
            <div class="card-body">

<?php



 $accesory= Accesory_product::where('accesory_id','=',$accessories->pivot->accesory_id)
->where('product_id','=',$accessories->pivot->product_id)
->get('id');

//settype($accesory, 'string'); 

 ?>
 <?php foreach ($accesory as $key => $value): ?>

<form id="formAP" action="<?php echo e(route('admin.accesory_product.update', $value->id)); ?>" method="POST">
                 <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('PUT')); ?>

               <b>Producto: </b><input type="text" name="" class="form-control" value="<?php echo e(old('name', isset($product) ? $product->name : '')); ?>" readonly><br>
               <input type="hidden"  class="form-control" name="product_id" class="form-control" value=
"<?php echo e(old('product_id', isset($accessories) ? $accessories->pivot->product_id: '')); ?>">
               <b>Accesorio:</b>
               <input type="hidden" name="accesory_id" class="form-control"value="<?php echo e(old('accesory_id', isset($product) ? $accessories->pivot->accesory_id : '')); ?>">
               <input type="text" name="" class="form-control"
               value="<?php echo e(old('name', isset($product) ? $accessories->name : '')); ?>" readonly><br>
               <b>Cantidad:</b>
               <input type="number" min="1" class="form-control" name="required" value="<?php echo e(old('required', isset($accessories) ? $accessories->pivot->required: '')); ?>"><br>
               
                <input type="hidden" name="id" value="<?php echo e($value->id); ?>">
                   
               <?php endforeach ?>

   <input type="hidden" value="<?php echo e(old('id', isset($product) ? $accessories->pivot->accesory_id: '')); ?>">
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="Guardar">
            </div>
         </form>
     </div>
 </div>
       
    </div>
  </div>          
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>