 <title><?php echo e(trans('panel.site_title')); ?></title>
  

<?php
use App\Quotation;
use App\ServiciosQuotation;
use App\CaracteristicasQuotation;
use App\Client;
use Symfony\Component\HttpFoundation\Response;
setlocale(LC_TIME, 'es_ES', 'esp_esp'); 

$cotizaciones = Quotation::all();
$id= $_GET["id"];
if (empty($_GET["id"])) {
    exit;
}
 

if(!Quotation::find($id)){
    echo (Response::HTTP_FORBIDDEN.' | Forbidden');
    return back();
}else{
    $cotizacion = Quotation::find($id)->where('id', $id)->get('quotation_date');

}
if (!$cotizacion) {
    exit("No existe la cotización");
}
$quotation_id = $_GET['id']; 
$servicios = ServiciosQuotation::all()->where('quotation_id', $quotation_id);

$caracteristicas = CaracteristicasQuotation::all()->where('quotation_id', $quotation_id);
$cliente = DB::table('clients')->join('quotes', 'clients.id','=','quotes.client_id')->select('clients.first_name', 'clients.last_name')->where('quotes.id', $quotation_id)->get();
$descuent = Quotation::all()->where('id', $quotation_id);
?>
<meta http-equiv="content-type" content="text/html; utf-8">
<div>
        <div class="col-sm" align="center">
        	<p style="font-size: xx-small;"><img src="./img/LOGO.png" style="max-height: 67px;"><br>INVERSIONES DIVERSAS DE ORIENTE S. DE R.L.<br>
        		Col. Villa Vieja 3.5 km carretera a Danlí, frente a Yonker Jireh, Tegucigalpa M.D.C.<br>
        		R.T.N. 08019017957660 Tel. :(504) 2243-2948 / 3362-2139,<br>
        	Correo: alumax.hn@gmail.com</p>
        </div>

    <div class="row">
        <div class="col-sm-8">
             <div>
             <strong style="font-size:small;">COTIZACIÓN #<?php echo e($id); ?></strong>
           
             	<?php $__currentLoopData = $cotizacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             	<p style="font-size:x-small;">Tegucigalpa M.D.C. <?php echo e(strtolower(strftime("%d de %B de %Y", strtotime($cotizacion->quotation_date)))); ?>

             	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br><b>

             	<?php foreach ($cliente as $key => $value): ?>
             		CLIENTE: <?php echo e(strtoupper($value->first_name)); ?> <?php echo e(strtoupper($value->last_name)); ?>

             	<?php endforeach ?></b></p>
            <p style="font-size:x-small;">Ha solicitado información sobre los precios de nuestra compañía. A continuación, se indica nuestro presupuesto:</p>
              </div>
                    <div class="row">
                                <table  border="1" cellspacing="0" style="font-size: x-small;">
                                    <thead style="background-color: #C0C0C0;">
                                    <tr>
                                        <th width="10%">Cantidad</th>
                                        <th width="50%">Producto</th>
                                        <th width="20%">Precio Unitario</th>
                                        <th width="15%">Precio Total</th>
                                        
                                    </tr>
                                    </thead>
                                    <tbody cellspacing="0" cellpadding="5">
                                    <?php
                                    $subTotal = 0.00;
                                    $descuento = 0.00;
                                    $TOTAL = 0.00;
                                    $pre_tot = 0.00;
                                    $isv= 0.00;

                                    ?>
                                    <?php 
                                    foreach ($servicios as $servicio) {
 
                                        ?>
                                        <tr >
                                            <td align="center" height= "30px" style="border-bottom: dotted;"><?php echo e($servicio->cantidad); ?></td>
                                            <td cellpadding="5"  style="border-bottom: dotted;"><?php echo htmlentities($servicio->servicio)." de "."$servicio->ancho"."x"."$servicio->alto"." m" ?></td>
                                            

                                            <td align="right" height= "30px" style="border-bottom: dotted;" ><?php 
                                            $unitario = $servicio->costo;
                                            $pre_unit= round($unitario *(1/1.15), 2);
                                             ?><?php echo e(number_format($pre_unit, 2)); ?>


                                            </td>
                                            <td align="right" height= "30px"  style="border-bottom: dotted;"><?php 
                                            $cant= $servicio->cantidad;
                                            $pre_tot= round($pre_unit * $cant, 2);
                                            $subTotal += $pre_tot;
                                             ?><?php echo e(number_format($pre_tot, 2)); ?>

                                            </td>                   
                                        </tr>
                  
                                    <?php } ?>
 
                                    </tbody>

                                    <tbody>
                                        
                                    <tr>
                                    	<td height="1%" colspan="2" rowspan="2" align="center" style="border-top: double;"><label style="color:#536197;"><b>Garantía de un año</b></label></td>
                                        <td align="right" style="border-top: double;"><strong>Sub-Total L.</strong></td>
                                        <td align="right" style="border-top: double; "><strong><?php echo e(number_format($subTotal, 2)); ?> 
                                                </strong></td>
                                              
                                    </tr>
                                    <tr >
                                    
                                        <td align="right" style="font-size: xx-small; border-top: medium groove;">Desc. y Rebaja L.</td>
                                        <td align="right" style="border-top: medium groove;"><strong> 
   
                                            <?php $__currentLoopData = $descuent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php  $descuento = number_format($desc->descuento, 2);?>
                                            <?php echo e($descuento); ?>

                                                </strong></td>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                </strong></td>
                                              
                                    </tr>
                                     <tr>
                                    	<td colspan="2" rowspan="7" valign="left" style="border-top: medium groove;">
                                    		<b>
                                    			<?php foreach ($caracteristicas as $caracteristica) { ?>
                                    			<?php echo e($caracteristica->caracteristica); ?><br><br>
                                    			<?php } ?>
                                    		</b>
                                    	</td>
                                        <td align="right" style="font-size: xx-small; border-top: medium groove;">Importe Exonerado L.</td>
                                        <td align="right" style="border-top: medium groove;"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>
                                     <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">Importe Exento L.</td>
                                        <td align="right"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>
                                     <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">Importe Gravado 15% L.</td>
                                        <td align="right"><strong><?php echo e(number_format($subTotal, 2)); ?> 
                                                </strong></td>
                                              
                                    </tr>
                                    <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">Importe Gravado 18% L.</td>
                                        <td align="right"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>

                                    <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">15% I.S.V. L.</td>
                                        <td align="right"><strong><?php
                                        $isv = round($subTotal * 0.15, 2);
                                        ?> <?php echo e(number_format($isv, 2)); ?>

                                                </strong></td>
                                              
                                    </tr>

                                     <tr>
                                    	
                                        <td align="right" style="font-size: xx-small;">18% I.S.V. L.</td>
                                        <td align="right"><strong> 0.00
                                                </strong></td>
                                              
                                    </tr>
                                    
                                     <tr>
                                    	
                                        <td align="right" style="border-top: medium solid;"><strong>TOTAL L.</strong></td>
                                        <td align="right" style="border-top: medium solid;"><strong><?php
                                        $TOTAL = $subTotal -$descuento + $isv;
                                        ?> <?php echo e(number_format($TOTAL, 2)); ?>

                                                </strong></td>
                                              
                                    </tr>
                                    </tbody>
                                </table>
                    </div>

                </div>
    </div>
    <div class="row">
        <div class="col-sm">
          <p align="center" style="font-size: small"><b>
          	Condiciones: adelanto del 50% al momento de empezar el trabajo y el 50% restante al concluir
el mismo.
          <b></p>  
        </div>
    </div>
    <hr>
    <div class="footer">
        <div class="col-sm">
          <p style="font-size: small" align="center">Julio Cesar Santos<br>
          	Jefe de Negocios y Proyectos
          </p>
        </div>
    </div>


    <div class="row">
        <div class="col-sm">
            <br>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/quotes/create.blade.php ENDPATH**/ ?>