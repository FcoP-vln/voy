
<head>
<style type="text/css">


/* Estilos del contenedor */
.sidebar {


  width: auto;
  height: 900px;
}

/* Tamaño del scroll */
.sidebar::-webkit-scrollbar {
  width: 8px;
}

 /* Estilos barra (thumb) de scroll */
.sidebar::-webkit-scrollbar-thumb {
  background: #ccc;
  border-radius: 4px;
}

.sidebar::-webkit-scrollbar-thumb:active {
  background-color: #999999;
}

.sidebar::-webkit-scrollbar-thumb:hover {
  background: #b3b3b3;
  box-shadow: 0 0 2px 1px rgba(0, 0, 0, 0.2);
}

 /* Estilos track de scroll */
.sidebar::-webkit-scrollbar-track {
  background: #e1e1e1;
  border-radius: 4px;
}

.sidebar::-webkit-scrollbar-track:hover, 
.sidebar::-webkit-scrollbar-track:active {
  background: #d4d4d4;
}
</style>
</head>
<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="<?php echo e(('/')); ?>admin" class="brand-link">
<img src="/img/LOGO.png" alt="alumax_logo" class="image elevation-4" style="max-height: 77px;"
           style="opacity: .8">
        <span class="brand-text font-weight-light"></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.clients.index")); ?>" class="nav-link <?php echo e(request()->is('admin/clients') || request()->is('admin/clients/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-user-plus">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.client.title')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.projects.index")); ?>" class="nav-link <?php echo e(request()->is('admin/projects') || request()->is('admin/projects/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-briefcase">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.project.title')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('note_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.notes.index")); ?>" class="nav-link <?php echo e(request()->is('admin/notes') || request()->is('admin/notes/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-sticky-note">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.note.title')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('document_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.documents.index")); ?>" class="nav-link <?php echo e(request()->is('admin/documents') || request()->is('admin/documents/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-file-alt">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.document.title')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.products.index")); ?>" class="nav-link <?php echo e(request()->is('admin/products') || request()->is('admin/products/*') ? 'active' : ''); ?>">
                            <i class="fa-fw far fa-window-restore">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.product.title')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cost_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.costs.index")); ?>" class="nav-link <?php echo e(request()->is('admin/costs') || request()->is('admin/costs/*') || request()->is('admin/accesories/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-window-restore">
                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.cost.title')); ?>/<?php echo e(trans('cruds.cost.title_list')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.transactions.index")); ?>" class="nav-link <?php echo e(request()->is('admin/transactions') || request()->is('admin/transactions/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-credit-card">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.transaction.title')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotes_access')): ?>  
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.quotes.index")); ?>" class="nav-link <?php echo e(request()->is('admin/quotes') || request()->is('admin/quotes/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-file-invoice-dollar">

                            </i>
                            <p>
                                <span><?php echo e(strtoupper(trans('cruds.quotes.title'))); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bills_access')): ?>  
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.bills.index")); ?>" class="nav-link <?php echo e(request()->is('admin/bills') || request()->is('admin/bills/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-file-invoice">

                            </i>
                            <p>
                                <span><?php echo e(strtoupper(trans('cruds.bills.title'))); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
               <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receipts_access')): ?>  
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.receipts.index")); ?>" class="nav-link <?php echo e(request()->is('admin/receipts') || request()->is('admin/receipts/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-receipt">

                            </i>
                            <p>
                                <span><?php echo e(strtoupper(trans('cruds.receipts.title'))); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_report_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.client-reports.index")); ?>" class="nav-link <?php echo e(request()->is('admin/client-reports') || request()->is('admin/client-reports/*') ? 'active' : ''); ?>">
                            <i class="fa-fw fas fa-chart-line">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.clientReport.title')); ?></span>
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_management_setting_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is('admin/currencies*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/transaction-types*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/income-sources*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/client-statuses*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/project-statuses*') ? 'menu-open' : ''); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fas fa-cogs">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.clientManagementSetting.title')); ?></span>
                                <i class="right fa fa-fw fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('currency_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.currencies.index")); ?>" class="nav-link <?php echo e(request()->is('admin/currencies') || request()->is('admin/currencies/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-money-bill">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.currency.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('transaction_type_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.transaction-types.index")); ?>" class="nav-link <?php echo e(request()->is('admin/transaction-types') || request()->is('admin/transaction-types/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-money-check">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.transactionType.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('income_source_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.income-sources.index")); ?>" class="nav-link <?php echo e(request()->is('admin/income-sources') || request()->is('admin/income-sources/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-database">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.incomeSource.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('client_status_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.client-statuses.index")); ?>" class="nav-link <?php echo e(request()->is('admin/client-statuses') || request()->is('admin/client-statuses/*') ? 'active' : ''); ?>">
                                     <i class="fas fa-user-check">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.clientStatus.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('project_status_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.project-statuses.index')); ?>" class="nav-link <?php echo e(request()->is('admin/project-statuses') || request()->is('admin/project-statuses/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-briefcase">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.projectStatus.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('admin.caracteristica_quotes.index')); ?>" class="nav-link <?php echo e(request()->is('admin/caracteristica_quotes') || request()->is('admin/aracteristica_quotes/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-file-contract">

                                        </i>
                                        <p>
                                            <span>Características Cotización</span>
                                        </p>
                                    </a>
                                </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is('admin/permissions*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/roles*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/users*') ? 'menu-open' : ''); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw fas fa-users">

                            </i>
                            <p>
                                <span><?php echo e(trans('cruds.userManagement.title')); ?></span>
                                <i class="right fa fa-fw fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is('admin/permissions') || request()->is('admin/permissions/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.permission.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is('admin/roles') || request()->is('admin/roles/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-briefcase">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.role.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is('admin/users') || request()->is('admin/users/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-user">

                                        </i>
                                        <p>
                                            <span><?php echo e(trans('cruds.user.title')); ?></span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sobrante_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is('admin/permissions*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/roles*') ? 'menu-open' : ''); ?> <?php echo e(request()->is('admin/users*') ? 'menu-open' : ''); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw fas fa-server">

                            </i>
                            <p>
                                <span>Otros</span>
                                <i class="right fa fa-fw fa-angle-left"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('backups_access')): ?>
                                <li class="nav-item">
                                    <a href="/backup" class="nav-link <?php echo e(request()->is('backup') || request()->is('backup/*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-database">

                                        </i>
                                        <p>
                                            <span>Respaldo/Restauración</span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('binnacle_access')): ?>
                                <li class="nav-item">
                                    <a href="/bitacora" class="nav-link <?php echo e(request()->is('bitacora') || request()->is('bitacora*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-file-contract">

                                        </i>
                                        <p>
                                            <span>Bitácora</span>
                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sobrante_access')): ?>
                            <li class="nav-item">
                                    <a href="<?php echo e(route('admin.sobrantes.index')); ?>" class="nav-link <?php echo e(request()->is('admin/sobrantes') || request()->is('admin/sobrantes*') ? 'active' : ''); ?>">
                                        <i class="fa-fw fas fa-window-restore"">

                                        </i>
                                        <p>
                                            <span>Sobrantes</span>
                                        </p>
                                    </a>
                            </li>
                       
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                        <p>
                            <i class="fas fa-fw fa-sign-out-alt">

                            </i>
                            <span><?php echo e(trans('global.logout')); ?></span>
                        </p>
                    </a>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/partials/menu.blade.php ENDPATH**/ ?>