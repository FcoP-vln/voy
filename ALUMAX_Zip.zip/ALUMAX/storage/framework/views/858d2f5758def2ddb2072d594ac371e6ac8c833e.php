
<?php $__env->startSection('content'); ?>
<div class="login-box">
    <div class="login-logo">
        <div class="login-logo">
            <a href="#">
                <?php echo e(trans('panel.site_title')); ?>

            </a>
        </div>
    </div>
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg"><?php echo e(trans('global.reset_password')); ?></p>
            <form method="POST" action="<?php echo e(route('password.request')); ?>">
                <?php echo e(csrf_field()); ?>

                <div>
                    <input name="token" value="<?php echo e($token); ?>" type="hidden">
                    <div class="form-group has-feedback">
                        <input type="email" name="email" class="form-control" required placeholder="<?php echo e(trans('global.login_email')); ?>">
                        <?php if($errors->has('email')): ?>
                            <p class="help-block">
                                <?php echo e($errors->first('email')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" name="password" class="form-control" required placeholder="<?php echo e(trans('global.login_password')); ?>">
                        <?php if($errors->has('password')): ?>
                            <p class="help-block">
                                <?php echo e($errors->first('password')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="form-group has-feedback">
                        <input type="password" name="password_confirmation" class="form-control" required placeholder="<?php echo e(trans('global.login_password_confirmation')); ?>">
                        <?php if($errors->has('password_confirmation')): ?>
                            <p class="help-block">
                                <?php echo e($errors->first('password_confirmation')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 text-right">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">
                            <?php echo e(trans('global.reset_password')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>