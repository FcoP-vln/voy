
<?php $__env->startSection('content'); ?>

<?php
   use App\ServiciosQuotation;
   use APP\Cost;

use App\Quotation;
use App\Client;
use App\ClientStatus;
$cotizaciones = Quotation::all()->sortBy('id');
$clientes = Client::all()->sortByDesc('id');
$statuses = ClientStatus::all();
?>

<div class="row">
    <div class="col-sm">
        <h1><?php echo e(trans('cruds.quotes.title')); ?></h1>
        
    </div>
</div>

<div class="row">
    <div class="col-sm">
        <p>
            <a href="#new" class="btn btn-success" data-toggle="modal">
                <i class="fa fa-plus"></i> <?php echo e(trans('cruds.quotes.fields.new')); ?>

            </a>
        </p>   
    </div>
   
    
    
</div>

<div class="card">
    <div class="card-header">
       <?php echo e((trans('cruds.quotes.title'))); ?> - <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover datatable datatable-Quotation">
                <thead>
                <tr>
                    <th width="10"></th>
                    <th>#</th>
                    <th><?php echo e(trans('cruds.quotes.fields.client')); ?></th>
                    <th><?php echo e(trans('cruds.quotes.fields.state')); ?></th>
                    <th><?php echo e(trans('cruds.quotes.fields.date')); ?></th>
                    <th><?php echo e(trans('cruds.quotes.fields.details')); ?></th>
                    <th><?php echo e(trans('cruds.quotes.fields.buy')); ?></th>
                    <th><?php echo e(trans('global.datatables.print')); ?></th>
                    <th><?php echo e(trans('global.edit')); ?></th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotes_delete')): ?>
                    <th><?php echo e(trans('global.delete')); ?></th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $cotizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($cotizacion->id); ?>">
                        <td>
                            
                        </td>
                        <td><?php echo e($cotizacion->id ?? ''); ?>   
                        </td>
                        <td><?php echo htmlentities($cotizacion->client->first_name) ??''?> <?php echo htmlentities($cotizacion->client->last_name ?? '') ?>     
                        </td>
                        <td><?php echo htmlentities($cotizacion->description ?? '') ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($cotizacion->quotation_date)) ?? ''); ?></td>
                        <td align="center">
                            <a class="btn btn-info"
                               href="<?php echo e(route('admin.quotes.show', [$cotizacion->id])); ?>/?id=<?php echo $cotizacion->id ?>" >
                                <i class="fa fa-info"></i>
                            </a>
                        </td>
                        <td>
                             <a class="btn btn-secondary"
                               href="<?php echo e(route('admin.quotes.edit', [$cotizacion->id])); ?>/?id=<?php echo $cotizacion->id ?>" >
                                <i class="fas fa-shopping-basket"></i>
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-primary"
                                href='/admin/imprimir/?id=<?php echo $cotizacion->id ?>' target="_blank">
                                <i class="fa fa-print"></i>
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-warning"
                               href="#edit<?php echo e($cotizacion->id); ?>" data-toggle="modal">
                                <i class="fa fa-edit"></i>
                            </a>
                        </td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotes_delete')): ?>
                        <td>
                            <form action="<?php echo e(route('admin.quotes.destroy', $cotizacion->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn btn-danger"> <i class="fa fa-trash"></i> </button>
                            </form>
                        </td>    
                             <?php endif; ?>
                    </tr>
                                     
                                              <!-- MODAL EDITAR-->
                            <div class="modal fade" id="edit<?php echo e($cotizacion->id); ?>" tabindex="-1" role="dialog" >
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1><?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.quotes.title_singular')); ?> #<?php echo e($cotizacion->id); ?></h1>
                                                </div>
                                            </div>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                                                <span aria-hidden="true">&times</span>
                                            </button> 
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="<?php echo e(route('admin.quotes.update', [$cotizacion->id])); ?>" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <?php echo e(csrf_field()); ?>

                                                 <?php echo e(method_field('PUT')); ?>

                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
                                               </div>
                                               <div class="form-group">

                                                <label for="client_id"><?php echo e(trans('cruds.quotes.fields.client')); ?>:</label>
                                                
                                                <select required class="form-control" name="client_id" id="client_id">
                                                    <?php foreach ($clientes as $cliente) { ?>
                                                        <option value="<?php echo $cliente->id ?>" <?php echo e((isset($cotizacion) && $cotizacion->client ? $cotizacion->client->id : old('client_id')) == $cliente->id  ? 'selected' : ''); ?>>

                                                            <?php echo htmlentities($cliente->first_name) ?> <?php echo htmlentities($cliente->last_name) ?></option>
                                                        <?php } ?>
                                                    </select>
                                                 

                                            </div>
                                            <div class="form-group">
                                                <label for="description"><?php echo e(trans('cruds.quotes.fields.state')); ?>:</label>
                                                
                                                <select autofocus required class="form-control" name="description" required>
                                                    <?php foreach ($statuses as $status) { ?>
                                                        <option value="<?php echo $status->name ?>" <?php echo e((isset($cotizacion) && $cotizacion->description ? $cotizacion->description : old('description')) == $status->name  ? 'selected' : ''); ?>>

                                                            <?php echo e($status->name); ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                                <div class="form-group">
                                                    <label for="quotation_date"><?php echo e(trans('cruds.quotes.fields.date')); ?>:</label>
                                                    <input value="<?php echo e(old('quotation_date', isset($cotizacion) ? $cotizacion->quotation_date : '')); ?>" name="quotation_date" autocomplete="off" required type="date"
                                                    class="form-control" id="fecha" >
                                                </div>  

                                                <div class="modal-footer">
                                                    <input type="submit" class="btn btn-primary" value="<?php echo e(trans('cruds.receipts.fields.save_changes')); ?>">
                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
                    <!-- fin modal editar -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row">
    <!-- MODAL CREAR-->
  <div class="modal fade" id="new" tabindex="-1" role="dialog" >
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-sm">
                        <?php $new = $cotizacion->id ?? '';
                              $nueva= $new + 1; 
                         ?>
                        <h1><?php echo e(trans('cruds.quotes.fields.new')); ?> #<?php echo e($nueva); ?></h1>
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
                    <span aria-hidden="true">&times</span>
                </button> 
            </div>

            <div class="modal-body">
               <div class="card">
                <div class="card-body">
            <form id="formAP" action="#" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo e(csrf_field()); ?>

               <?php echo e(method_field('POST')); ?>

               <div class="form-group">
             <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
            </div>
            <div class="form-group">
             <input type="hidden" name="quotation_id" value="<?php echo e($nueva); ?>">  
            </div>
               <div class="form-group">

                <label for="client_id"><?php echo e(trans('cruds.quotes.fields.select')); ?>:</label>
                <select required class="form-control" name="client_id" id="client_id">
                    <?php foreach ($clientes as $cliente) { ?>
                        <option value="<?php echo $cliente->id ?>"><?php echo htmlentities($cliente->first_name) ?> <?php echo htmlentities($cliente->last_name) ?></option>
                    <?php } ?>
                </select>
             
              </div>
              <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.quotes.fields.state')); ?>:</label>
               
               <select required class="form-control" name="description" required>
                    <?php foreach ($statuses as $status) { ?>
                        <option value="<?php echo htmlentities($status->name)?>"><?php echo e($status->name); ?></option>
                    <?php } ?>
                </select>
                </div>
              <div class="form-group">
                <label for="quotation_date"><?php echo e(trans('cruds.quotes.fields.date')); ?>:</label>
                <input value="<?php echo date("Y-m-d") ?>" name="quotation_date" autocomplete="off" required type="date"
                       class="form-control" id="fecha">
            </div>  
    
            <div class="modal-footer">
                <input type="submit" class="btn btn-primary" value="<?php echo e(trans('global.create')); ?>">
            </div>

          </form>
      </div>
      </div>
    </div>
</div>
</div>
</div>    
<!-- fin modal -->
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('quotes_delete')): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.quotes.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      }); 

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  $('.datatable-Quotation:not(.ajaxTable)').DataTable({ buttons: dtButtons })
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
})

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/quotes/index.blade.php ENDPATH**/ ?>