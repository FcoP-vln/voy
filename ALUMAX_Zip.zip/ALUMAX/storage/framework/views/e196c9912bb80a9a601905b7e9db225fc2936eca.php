
<?php $__env->startSection('content'); ?>
<?php
   use App\ServiciosQuotation;
   use APP\Cost;

use App\Quotation;
use App\Client;
use App\ClientStatus;
$quotation_id = $_GET['id']??''; 
$cotizaciones = Quotation::all()->where('id', $quotation_id);

?>


 <?php $__currentLoopData = $cotizaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cotizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                            <div class="card">
                                    <div class="card-body">
                                        <div class="card-header">
                                            <div class="row">
                                                <div class="col-sm">
                                                    <h1>Compra requerida para Cotización #<?php echo e($cotizacion->id); ?></h1>
                                                </div>
                                            </div>
                            
                                        </div>

                                        <div class="modal-body">
                                         <div class="card">
                                            <div class="card-body">
                                                <form id="formAP" action="<?php echo e(route('admin.sobrantes.store')); ?>" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <?php echo e(csrf_field()); ?>

                                                 <?php echo e(method_field('POST')); ?>

                                                 <div class="form-group">
                                                   <input type="hidden" name="user_id" placeholder="<?php echo e(auth()->user()->id); ?>" value="<?php echo e(auth()->user()->id); ?>">  
                                                  <!--  <input type="hidden" name="quotation_id" value="<?php echo e($cotizacion->id ?? ''); ?>"> -->
                                               </div>
                                               <div class="form-group">

                                                <label for="client_id">Producto:</label>
                                <?php 
                          
                                $servicios = ServiciosQuotation::all()->where('quotation_id', $cotizacion->id);
                                

                                 ?>                
                                                
                                          <?php foreach ($servicios as $ser) { ?>
                                                        
                                                      <h4><?php echo e($ser->servicio); ?> (<?php echo e($ser->cantidad); ?>) - <?php echo e($ser->ancho); ?> x <?php echo e($ser->alto); ?> m</h4>
                                                      <table border="2" class="table table-bordered table-striped">
                                                      	  <tr>
                                                            	<th>Material</th>
                                                            	<th>Cantidad a utilizar (metros)</th>
                                                            	<th>Cantidad a comprar(lance/rollo)</th>
                                                            	<th>Sobrante (metros)</th>
                                                              <th>Agregar a Inventario</th>
                                                            </tr>  

                                                      <?php  
                                                        $nom=$ser->servicio;
                                                        $name= DB::select('SELECT * from products where name='.'"'.$nom.'"');
                                                        $pro = $name;

                                                        foreach ($pro as $key => $dato) {
                                                          $p_id= $dato->id;                                   

                                                                   $materiales = DB::select('SELECT * from cost_product where product_id='.$p_id);
                                                          ;
                                                          foreach ($materiales as $key => $material) {
                                                            $mat_id=$material->cost_id;

                                                            $mat_nom = DB::select('SELECT * from costs where id='.$mat_id);
                                                            foreach ($mat_nom as $key => $mate) {?>
                                                         <!--  <input type="hidden" name="material[]" value="<?php echo e($mate->name ?? ''); ?>"> -->
 
<tr>
                                                            <td> <?php echo e($mate->name); ?></td>
                                                            <td class="text-center">
                                                            	<?php 
                                                            	$ancho = $ser->ancho;
                                                            	$alto = $ser->alto;
                                                            	$ancho_re= $mate->width_required;
                                                            	$alto_re= $mate->high_required;
                                                            	$cant = $ser->cantidad;
                                                            	 $larg = $mate->longsize;
                                                            	 $stot1= $ancho*$ancho_re;
                                                            	 $stot2= $alto*$alto_re;
                                                            	 $stotal = $stot1+$stot2;
                                                            	 $total=$stotal*$cant;
                                                            	?>
                                                            	<?php echo e($total); ?>


                                                            </td>
                                                            <td class="text-center">
                                                            	<?php $comprar=($total*100)/$larg;?>
                                                            	<?php echo e(ceil($comprar)); ?>		
                                                           	</td>
                                                            <td class="text-center"><?php 
                                                            	$ctd_exacta = $comprar;
                                                            	$larg=ceil($comprar)*$mate->longsize;
                                                            	$lance= $larg/100;
                                                            	$sobrante=$lance - $total;

                                                             ?><?php echo e($sobrante); ?></td>
                                                           <!--   <input type="hidden" name="cantidad" value="<?php echo e($sobrante ?? ''); ?>"> -->
                                                             <td>
                                                               <form action="<?php echo e(route('admin.sobrantes.store')); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                                                <?php echo csrf_field(); ?>
                                                 <?php echo e(csrf_field()); ?>

                                                 <?php echo e(method_field('POST')); ?>

                                        <input type="hidden" name="quotation_id" value="<?php echo e($cotizacion->id); ?>">
                                        <input type="hidden" name="material" value="<?php echo e($mate->name); ?>">
                                         <input type="hidden" name="cantidad" value="<?php echo e($sobrante); ?>">
                                        <input type="submit" class="btn btn-xs btn-primary" value="<?php echo e(trans('global.add')); ?>">
                                          
                                    </form>
                                                                      
                                                             </td>
                                                         </tr>
                                                             
                                                            <?php  }
                                                            
                                                          }


                                                 
                                                        }

                                                      ?>  
                                                      </table>

                                          <?php } ?>
                                                       
                                                         
                                           

                                            </div>
                                            

                                                <div class="modal-footer">
                                                  <!--   <input type="submit" class="btn btn-primary" value="Guardar materiales sobrantes"> -->
                                                      <a style="margin-left:20px;" class="btn btn-default" href="<?php echo e(route('admin.quotes.index')); ?>">
                        <?php echo e(trans('global.back_to_list')); ?>

                    </a>

                                                </div>

                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>    
          
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/quotes/edit.blade.php ENDPATH**/ ?>