
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.project.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.projects.update", [$project->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.project.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($project) ? $project->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.project.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('client_id') ? 'has-error' : ''); ?>">
                <label for="client"><?php echo e(trans('cruds.project.fields.client')); ?>*</label>
                <select name="client_id" id="client" class="form-control select2" required>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($project) && $project->client ? $project->client->id : old('client_id')) == $id ? 'selected' : ''); ?>><?php echo e($client); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('client_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('client_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.project.fields.description')); ?></label>
                <textarea id="description" name="description" class="form-control "><?php echo e(old('description', isset($project) ? $project->description : '')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('description')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.project.fields.description_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('start_date') ? 'has-error' : ''); ?>">
                <label for="start_date"><?php echo e(trans('cruds.project.fields.start_date')); ?></label>
                <input type="text" id="start_date" name="start_date" class="form-control date" value="<?php echo e(old('start_date', isset($project) ? $project->start_date : '')); ?>">
                <?php if($errors->has('start_date')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('start_date')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.project.fields.start_date_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('budget') ? 'has-error' : ''); ?>">
                <label for="budget"><?php echo e(trans('cruds.project.fields.budget')); ?></label>
                <input type="number" id="budget" name="budget" class="form-control" value="<?php echo e(old('budget', isset($project) ? $project->budget : '')); ?>" step="0.01">
                <?php if($errors->has('budget')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('budget')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.project.fields.budget_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('status_id') ? 'has-error' : ''); ?>">
                <label for="status"><?php echo e(trans('cruds.project.fields.status')); ?></label>
                <select name="status_id" id="status" class="form-control select2">
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($project) && $project->status ? $project->status->id : old('status_id')) == $id ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('status_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/projects/edit.blade.php ENDPATH**/ ?>