
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.cost.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.costs.update', [$cost->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.cost.fields.name')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($cost) ? $cost->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('name')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('products') ? 'has-error' : ''); ?>">
                <label for="products">Para producto:
                    <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                <select name="products[]" id="products" class="form-control select2" multiple="multiple" required>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('products', [])) || isset($cost) && $cost->products->contains($id)) ? 'selected' : ''); ?>><?php echo e($products); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('products')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('products')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('white') ? 'has-error' : ''); ?>">
                <label for="white"><?php echo e(trans('cruds.cost.fields.white')); ?>*</label>
                <input type="number" min="0" id="white" name="white" class="form-control" value="<?php echo e(old('white', isset($cost) ? $cost->white : '')); ?>" step="0.01" required>
                <?php if($errors->has('white')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('white')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.white_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('bronze') ? 'has-error' : ''); ?>">
                <label for="bronze"><?php echo e(trans('cruds.cost.fields.bronze')); ?>*</label>
                <input type="number" min="0" id="bronze" name="bronze" class="form-control" value="<?php echo e(old('bronze', isset($cost) ? $cost->bronze : '')); ?>" step="0.01" required>
                <?php if($errors->has('bronze')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('bronze')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.bronze_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('wood') ? 'has-error' : ''); ?>">
                <label for="wood"><?php echo e(trans('cruds.cost.fields.wood')); ?>*</label>
                <input type="number" min="0" id="wood" name="wood" class="form-control" value="<?php echo e(old('wood', isset($cost) ? $cost->wood : '')); ?>" step="0.01" required>
                <?php if($errors->has('wood')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('wood')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.bronze_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('natural') ? 'has-error' : ''); ?>">
                <label for="natural"><?php echo e(trans('cruds.cost.fields.natural')); ?>*</label>
                <input type="number" min="0" id="natural" name="natural" class="form-control" value="<?php echo e(old('natural', isset($cost) ? $cost->natural : '')); ?>" step="0.01" required>
                <?php if($errors->has('natural')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('natural')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.natural_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('stock') ? 'has-error' : ''); ?>">
                <label for="stock"><?php echo e(trans('cruds.cost.fields.stock')); ?>*</label>
                <input type="number" min="0" id="stock" name="stock" class="form-control" value="<?php echo e(old('stock', isset($cost) ? $cost->stock : '')); ?>"  required>
                <?php if($errors->has('stock')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('stock')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.stock_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('width_required') ? 'has-error' : ''); ?>">
                <label for="width_required"><?php echo e(trans('cruds.cost.fields.width_required')); ?></label>
                <input type="number" min="0" id="width_required" name="width_required" class="form-control" value="<?php echo e(old('width_required', isset($cost) ? $cost->width_required : '')); ?>" step="0.1">
                <?php if($errors->has('width_required')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('width_required')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.width_required_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('high_required') ? 'has-error' : ''); ?>">
                <label for="high_required"><?php echo e(trans('cruds.cost.fields.high_required')); ?></label>
                <input type="number" min="0" id="high_required" name="high_required" class="form-control" value="<?php echo e(old('high_required', isset($cost) ? $cost->high_required : '')); ?>" step="0.1">
                <?php if($errors->has('high_required')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('high_required')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.high_required_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('longsize') ? 'has-error' : ''); ?>">
                <label for="longsize"><?php echo e(trans('cruds.cost.fields.longsize')); ?>/cm</label>
                <input type="number" min="1" id="longsize" name="longsize" class="form-control" value="<?php echo e(old('longsize', isset($cost) ? $cost->longsize : '')); ?>" required >
                <?php if($errors->has('longsize')): ?>
                    <p class="help-block">
                       <?php echo e($errors->first('longsize')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.longsize_helper')); ?>

                </p>
            </div>


            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.cost.fields.description')); ?>*</label>
                <textarea id="description" name="description" class="form-control " required><?php echo e(old('description', isset($cost) ? $cost->description : '')); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('description')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.cost.fields.description_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/costs/edit.blade.php ENDPATH**/ ?>