
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.note.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.notes.update", [$note->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('project_id') ? 'has-error' : ''); ?>">
                <label for="project"><?php echo e(trans('cruds.note.fields.project')); ?>*</label>
                <select name="project_id" id="project" class="form-control select2" required>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($note) && $note->project ? $note->project->id : old('project_id')) == $id ? 'selected' : ''); ?>><?php echo e($project); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('project_id')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('project_id')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('note_text') ? 'has-error' : ''); ?>">
                <label for="note_text"><?php echo e(trans('cruds.note.fields.note_text')); ?>*</label>
                <textarea id="note_text" name="note_text" class="form-control " required><?php echo e(old('note_text', isset($note) ? $note->note_text : '')); ?></textarea>
                <?php if($errors->has('note_text')): ?>
                    <p class="help-block">
                        <?php echo e($errors->first('note_text')); ?>

                    </p>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.note.fields.note_text_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\master-php\ALUMAX\resources\views/admin/notes/edit.blade.php ENDPATH**/ ?>